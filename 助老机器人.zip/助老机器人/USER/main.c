#include "stm32f10x.h"
#include "sys.h"
#include "usart.h"
#include "delay.h"
#include "stm32f10x_tim.h"

#include "user_Config.h"               //�û�����ͷ�ļ�����������Ӳ��������Դ,λ����Ŀ�ļ�����
#include "TFT28.h"

#include "pwm.h"
#include "timer.h"
#include "tftshow.h"
unsigned int intr,flag; 
unsigned int Device_code; 
void System_Init(void);
void GPIO_Config_TFT(void);
extern unsigned char ch,ch1,ch2,ch3,ch4,ch5,ch6,flags;
extern unsigned char rx[32],rx1[32],rx2[32],rx3[32],rx4[32],rx5[32],rx6[32];
extern unsigned char rxcnt,rxcnt1,rxcnt2,rxcnt3,rxcnt4,rxcnt5,rxcnt6;
extern unsigned char *text;
u8 ktaid=0,kfengs=0,kong=0;
u8 tongx=0;
extern u16 t5flag;
u8 re=20,hume=30,ref=0,menf=0,shuif=0,ran=0,pmf=0,shui=0,tqishan=0,chuangl=0,menj=0,linyu=0,cesuo=0,start=0;
u16 pm=0;
u8 shun=0,shun1=0,shun2=0,shun3=0,shun4=0,shun5=0,shun6=0;
extern u8 wenbao,shibao,huanj;
extern void yuyin(u8 shu);
extern void yuyins(u8 shu);
extern void yuyinh(void);
extern u8 cxt[32],cx1;
u8 autohand=0,qian=0,zuo60=0,zuo=0,zuo120=0,hou=0,you60=0,you=0,you120=0;
void ioinit(void)
{
  GPIO_InitTypeDef GPIOa;
	GPIOa.GPIO_Pin =GPIO_Pin_6 | GPIO_Pin_5;
	GPIOa .GPIO_Mode =GPIO_Mode_IPD ;
	GPIO_Init(GPIOA ,&GPIOa );
}
int main(void)
{	
	
 	extern u8 wenbao,shibao,huanj;
	
	delay_init();	    //��ʱ������ʼ��	
  System_Init();		//���ڳ�ʼ��
	
	
	//TFT��ʼ��
  Device_code = 0x9328; 			//TFT����IC�ͺţ�����ʵ�������ͺţ�Ŀǰ��9320��9328����
  GPIO_Config_TFT();	
   ioinit();	
	TFT_Initial(); 
	
	
	
    GPIO_ResetBits(GPIOB, GPIO_Pin_7);
		
	  TIM5_Int_Init(99,719);				//��ʱ5��ʼ��
//	TIM2_Int_Init(999,7199);				//��ʱ2��ʼ��
//	
//	TIM3_PWM_Init(899,0);					//PWM��ʼ��
 	  Show_RGB(0,240,0,320,White);
	  mainshow();
	  wenshishow('2','3','4','8');
		guang('1','0','2','4');
		PM2('2','3','4');
		ranqi('1');
		shuifa('1');
		menchuang('1');
		renyuan('1');
		taideng('1');
		fengshan('1');
		tongxin('0');
		qishan('0');
	while(1)
	{
		
		if(ch==1)
		{
		ch=0;
		delay_ms(500);
		u1_printf("\r\nAT+CWMODE=3\r\n");
		delay_ms(500);
		u1_printf("\r\nAT+CIPMUX=1\r\n");
		delay_ms(500);
		u1_printf("\r\nAT+CIPSERVER=1,8888\r\n");
		delay_ms(500);
		ch1=1;
		}
		if(ch2==1)
		{
		delay_ms(500);
		u1_printf("\r\nAT+CIPSEND=0,10\r\n");
		delay_ms(500);
		u1_printf("\r\nready!!!\r\n");
		delay_ms(500);
		ch2=0;
		tongx=1;
		}
		if(tongx==1)
		{
		tongxin('1');
		if(ref==1&&t5flag==1)
		{
		t5flag=0;
		u1_printf("\r\nAT+CIPSEND=0,22\r\n");
		delay_ms(500);
		u1_printf("\r\ntemperature warning!\r\n");
		delay_ms(500);	
		
		}
		if(menf==1&&t5flag ==1)
		{
		t5flag=0;
		u1_printf("\r\nAT+CIPSEND=0,15\r\n");
		delay_ms(500);
		u1_printf("\r\ndoor opening!\r\n");
		delay_ms(500);	

		}
		if(shuif==1&&t5flag ==1)
		{
		t5flag=0;
		u1_printf("\r\nAT+CIPSEND=0,16\r\n");
		delay_ms(500);
		u1_printf("\r\nwater leaking!\r\n");
		delay_ms(500);	

		}
		if(ran==1&&t5flag ==1)
		{
		t5flag=0;
		u1_printf("\r\nAT+CIPSEND=0,14\r\n");
		delay_ms(500);
		u1_printf("\r\ngas leaking!\r\n");
		delay_ms(500);
		
		}
	  if(pmf==1&&t5flag ==1)
		{
		t5flag=0;
		u1_printf("\r\nAT+CIPSEND=0,16\r\n");
		delay_ms(500);
		u1_printf("\r\nPM2.5 warning!\r\n");
		delay_ms(500);	

		}
		}
		else
		{
			tongxin('0');
		}
		if(ref==1)
		{
			Uart5SendChar(0xaa);
Uart5SendChar(0xfd);
Uart5SendChar(0x18);
Uart5SendChar(0x00);
Uart5SendChar(0xdf);
		}
		if(menf==1)
		{
		Uart5SendChar(0xaa);
Uart5SendChar(0xfd);
Uart5SendChar(0x17);
Uart5SendChar(0x00);
Uart5SendChar(0xdf);			
		}
		if(shuif==1)
		{
		Uart5SendChar(0xaa);
    Uart5SendChar(0xfd);
    Uart5SendChar(0x15);
    Uart5SendChar(0x00);
    Uart5SendChar(0xdf);
		}
		if(ran==1)
		{
    Uart5SendChar(0xaa);
    Uart5SendChar(0xfd);
    Uart5SendChar(0x14);
    Uart5SendChar(0x00);
    Uart5SendChar(0xdf);			
		}
		if(pmf==1)
		{
				Uart5SendChar(0xaa);
    Uart5SendChar(0xfd);
    Uart5SendChar(0x16);
    Uart5SendChar(0x00);
    Uart5SendChar(0xdf);
		}
		if(cx1==1)
		{
	   	cx1=0;
			if(cxt[1]=='a')
			{
			kong=1;
		  ktaid =0;
			}
			if(cxt[1]=='b')
			{
			kong=1;
		  ktaid =1;
			}
			if(cxt[1]=='c')
			{
			kong=1;
		  kfengs =0;
			}
			if(cxt[1]=='d')
			{
			kong=1;
		  kfengs =1;
			}
			if(cxt[1]=='e')
			{
			kong=1;
		  tqishan =0;
			}
			if(cxt[1]=='f')
			{
			kong=1;
		  tqishan =1;
			}
			if(cxt[1]=='g')
			{
			kong=1;
		  shui =0;
			}
			if(cxt[1]=='h')
			{
			kong=1;
		  shui=1;
			}
			if(cxt[1]=='i')
			{
			kong=1;
		  chuangl=0;
			}
			if(cxt[1]=='j')
			{
			kong=1;
		  chuangl=1;
			}
			if(cxt[1]=='k')
			{
			kong=1;
		  linyu=0;
			}
			if(cxt[1]=='l')
			{
			kong=1;
		  linyu=1;
			}
			if(cxt[1]=='m')
			{
			kong=1;
		  cesuo=0;
			}
			if(cxt[1]=='n')
			{
			kong=1;
		  cesuo=1;
			}
			if(cxt[1]=='o')
			{
			kong=1;
		  menj=0;
			}
			if(cxt[1]=='p')
			{
			kong=1;
		  menj=1;
			}
			if(cxt[1]=='q')
			{
			
		  start=0;
			}
			if(cxt[1]=='r')
			{
		
		  start=1;
			}
			if(cxt[1]=='s')
			{
			  kong=0;
			  qian=0;
				zuo60=0;
				zuo=0;
				zuo120=0;
				hou=0;
				you=0;
				you60=0;
				you120=0;
				
			}
			if(cxt[1]=='t')
			{
			zuo60=1;
			}
			if(cxt[1]=='u')
			{
			qian=1;
			}
			if(cxt[1]=='v')
			{
			you60=1;
			}
			if(cxt[1]=='w')
			{
			zuo=1;
			}
			if(cxt[1]=='x')
			{
			you=1;
			}
			if(cxt[1]=='y')
			{
			zuo120=1;
			}
			if(cxt[1]=='A')
			{
			hou=1;
			}
			if(cxt[1]=='B')
			{
			you120=1;
			}
			if(cxt[1]=='C')
			{
			autohand =1;
			}
			if(cxt[1]=='D')
			{
			autohand =0;
			}			
		}
//		if(zuo60==1)
//			{
//			  GPIO_SetBits(GPIOB, GPIO_Pin_6);
//				GPIO_SetBits(GPIOB, GPIO_Pin_5);
//				GPIO_SetBits(GPIOB, GPIO_Pin_4);
//				GPIO_ResetBits(GPIOB, GPIO_Pin_3);
//			}
//		if(qian==1)
//		{
//		    GPIO_SetBits(GPIOB, GPIO_Pin_6);
//				GPIO_SetBits(GPIOB, GPIO_Pin_5);
//				GPIO_SetBits(GPIOB, GPIO_Pin_4);
//				GPIO_ResetBits(GPIOB, GPIO_Pin_3);
//		}
//		if(you60==1)
//		{
//		    GPIO_SetBits(GPIOB, GPIO_Pin_6);
//				GPIO_SetBits(GPIOB, GPIO_Pin_5);
//				GPIO_SetBits(GPIOB, GPIO_Pin_4);
//				GPIO_ResetBits(GPIOB, GPIO_Pin_3);
//		}
//		if(zuo==1)
//		{
//		    GPIO_SetBits(GPIOB, GPIO_Pin_6);
//				GPIO_SetBits(GPIOB, GPIO_Pin_5);
//				GPIO_SetBits(GPIOB, GPIO_Pin_4);
//				GPIO_ResetBits(GPIOB, GPIO_Pin_3);
//		}
//		if(you==1)
//		{
//		    GPIO_SetBits(GPIOB, GPIO_Pin_6);
//				GPIO_SetBits(GPIOB, GPIO_Pin_5);
//				GPIO_SetBits(GPIOB, GPIO_Pin_4);
//				GPIO_ResetBits(GPIOB, GPIO_Pin_3);
//		}
//		if(zuo120==1)
//		{
//		    GPIO_SetBits(GPIOB, GPIO_Pin_6);
//				GPIO_SetBits(GPIOB, GPIO_Pin_5);
//				GPIO_SetBits(GPIOB, GPIO_Pin_4);
//				GPIO_ResetBits(GPIOB, GPIO_Pin_3);
//		}
//		if(hou==1)
//		{
//		    GPIO_SetBits(GPIOB, GPIO_Pin_6);
//				GPIO_SetBits(GPIOB, GPIO_Pin_5);
//				GPIO_SetBits(GPIOB, GPIO_Pin_4);
//				GPIO_ResetBits(GPIOB, GPIO_Pin_3);
//		}
//		if(you120==1)
//		{
//		    GPIO_SetBits(GPIOB, GPIO_Pin_6);
//				GPIO_SetBits(GPIOB, GPIO_Pin_5);
//				GPIO_SetBits(GPIOB, GPIO_Pin_4);
//				GPIO_ResetBits(GPIOB, GPIO_Pin_3);
//			
//		}
//		if(autohand ==1)
//		{
//		    
//				GPIO_SetBits(GPIOB, GPIO_Pin_2);
//		}
//		else
//		{
//			GPIO_ResetBits(GPIOB, GPIO_Pin_2);
//		}
		
		if(start==1)
		{
		GPIO_SetBits(GPIOB, GPIO_Pin_7);
		}
		else 
		{
		 GPIO_ResetBits(GPIOB, GPIO_Pin_7);
		}
		if(kong==0&&t5flag==1)
		{
		t5flag=2;
		if(kfengs==0&&ktaid==0)USART4_SendString("A000000000S00E");
		if(kfengs==0&&ktaid==1)USART4_SendString("A000000000S01E");
		if(kfengs==1&&ktaid==0)USART4_SendString("A000000000S10E");
		if(kfengs==1&&ktaid==1)USART4_SendString("A000000000S11E");		
		}
		else if(kong==1&&t5flag==1)
		{
		t5flag=2;	
		if(kfengs==0&&ktaid==0)USART4_SendString("A000000000M00E");
		if(kfengs==0&&ktaid==1)USART4_SendString("A000000000M01E");
		if(kfengs==1&&ktaid==0)USART4_SendString("A000000000M10E");
		if(kfengs==1&&ktaid==1)USART4_SendString("A000000000M11E");
		}
		if(ch3==1)
		{
		ch3=0;
		wenshishow(rx2[3],rx2[4],rx2[1],rx2[2]);
		guang(rx2[5],rx2[6],rx2[7],rx2[8]);	
		menchuang(rx2[9]);
		re=((rx2[3]-0x30)*10)+(rx2[4]-0x30);	
		hume=((rx2[1]-0x30)*10)+(rx2[2]-0x30);
		if(re>35)ref=1;
			else ref=0;
    if(rx2[9]=='1')menf=1;	
      else	menf=0;	
			fengshan (rx2[11]);
			taideng (rx2[12]);
		
		}
		if(t5flag==3&&kong==0)
		{
		t5flag=4;
		USART4_SendString("B000000000S00E");
		}
		else if(t5flag==3&&kong==1)
			{
		t5flag=4;
		if(shui==1&&linyu==1&&cesuo ==1)USART4_SendString("B100000000M11E");
	      else if(shui==1&&linyu==1&&cesuo ==0)USART4_SendString("B100000000M10E");
				else if(shui==1&&linyu==0&&cesuo ==1)USART4_SendString("B100000000M01E");
				else if(shui==1&&linyu==0&&cesuo ==0)USART4_SendString("B100000000M00E");
				else if(shui==0&&linyu==1&&cesuo ==1)USART4_SendString("B000000000M11E");
				else if(shui==0&&linyu==1&&cesuo ==0)USART4_SendString("B000000000M10E");
				else if(shui==0&&linyu==0&&cesuo ==1)USART4_SendString("B000000000M01E");
				else if(shui==0&&linyu==0&&cesuo ==0)USART4_SendString("B000000000M00E");
		}
		if(ch4==1)
		{
		ch4=0;
		shuifa(rx3[1]);
		if(rx3[1]=='1')shuif=1;
			else shuif=0;	 		
						
		}
	if(t5flag ==5&&kong==0)
	{
		t5flag=6;
	USART4_SendString("C000000000S00E");	
	}
	else if(t5flag==5&&kong==1)
			{
		  t5flag=6;
		  if(chuangl ==1&&menj==1&&ran ==1)USART4_SendString("C101100000M00E");
	      else if(chuangl ==1&&menj==1&&ran ==0)USART4_SendString("C001100000M00E");
				else if(chuangl ==1&&menj==0&&ran ==1)USART4_SendString("C100100000M00E");
				else if(chuangl ==1&&menj==0&&ran ==0)USART4_SendString("C000100000M00E");
				else if(chuangl ==0&&menj==1&&ran ==1)USART4_SendString("C101000000M00E");
				else if(chuangl ==0&&menj==1&&ran ==0)USART4_SendString("C001000000M00E");
				else if(chuangl ==0&&menj==0&&ran ==1)USART4_SendString("C100000000M00E");
				else if(chuangl ==0&&menj==0&&ran ==0)USART4_SendString("C000000000M00E");
			
		}
		if(ch5==1)
		{
		ch5=0;
		if(rx4[1]=='1'||rx5[2]=='1')
		{
		ranqi('1');
		ran=1;
		}
		else
    {
		ranqi('0');
		ran=0;
		}
		renyuan(rx4[2]);
			
		}
		if(t5flag ==7&&kong==0)
	{
  t5flag=8;
	USART3_SendString("D000000000S00E");	
	}	
	else if(t5flag ==7&&kong==1)
	{
	t5flag=8;
	if(tqishan==1)USART3_SendString("D100000000M00E");		
		else USART3_SendString("D000000000M00E");	
	}
		if(ch6==1)
		{
		ch6=0;
		if(rx4[1]=='1'||rx5[2]=='1')
		{
		ranqi('1');
		ran=1;
		}
		else
    {
		ranqi('0');
		ran=0;
		}
		PM2(rx5[4],rx5[5],rx5[6]);
		pm=((rx5[4]-0x30)*100)+((rx5[5]-0x30)*10)+(rx5[6]-0x30);
		if(pm>100)
		{
		pmf=1;
		}
		else
		{
		pmf=0;
		}
		qishan(rx5[1]);

		}
if((GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)&0x30)==0x20)
{
    Uart5SendChar(0xaa);
    Uart5SendChar(0xfd);
    Uart5SendChar(0x19);
    Uart5SendChar(0x00);
    Uart5SendChar(0xdf);
	  wenbao=1;
}
	 yuyin(re);	
 
   yuyins(hume);
	 yuyinh(); 
	
//		TIM_SetCompare3(TIM3,899);
//		TIM_SetCompare4(TIM3,0);		
//		for(t=0;t<=8999;t++)
//		{
//			TIM_SetCompare3(TIM3,t/10);
//			
//		}

		
//		if(UART5_RX_STA&0x8000)
//		{					   
//			len=UART5_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
//			u5_printf("\r\n�����͵���ϢΪ:\r\n");
//			for(t=0;t<len;t++)
//			{
//				UART5->DR=UART5_RX_BUF[t];
//				while((UART5->SR&0X40)==0);//�ȴ����ͽ���
//			}
//			u5_printf("\r\n\r\n");//���뻻��
//			UART5_RX_STA=0;
//		}
//				else
//		{
//			times++;
//			if(times%5000==0)
//			{
//				u5_printf("\r\nALIENTEK MiniSTM32������ ����ʵ��\r\n");
//				u5_printf("����ԭ��@ALIENTEK\r\n\r\n\r\n");
//			}
//			if(times%200==0)u5_printf("����������,�Իس�������\r\n");  
//			delay_ms(10);   
//		}
		
		
//		 if(USART1_RX_STA&0x8000)
//		{					   
//			len=USART1_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
//			u1_printf("\r\n�����͵���ϢΪ:\r\n");
//			for(t=0;t<len;t++)
//			{
//				USART1->DR=USART1_RX_BUF[t];
//				while((USART1->SR&0X40)==0);//�ȴ����ͽ���
//			}
//			u1_printf("\r\n\r\n");//���뻻��
//			USART1_RX_STA=0;
//		}
//        else
//		{
//			times++;
//			if(times%5000==0)
//			{
//				u1_printf("\r\nALIENTEK MiniSTM32������ ����ʵ��\r\n");
//				u1_printf("����ԭ��@ALIENTEK\r\n\r\n\r\n");
//			}
//			if(times%200==0)u1_printf("����������,�Իس�������\r\n");  
//			delay_ms(10);   
//		}
		


//		 if(USART2_RX_STA&0x8000)
//		{					   
//			len=USART2_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
//			u2_printf("\r\n�����͵���ϢΪ:\r\n");
//			for(t=0;t<len;t++)
//			{
//				USART2->DR=USART2_RX_BUF[t];
//				while((USART2->SR&0X40)==0);//�ȴ����ͽ���
//			}
//			u2_printf("\r\n\r\n");//���뻻��
//			USART2_RX_STA=0;
//		}
//        else
//		{
//			times++;
//			if(times%5000==0)
//			{
//				u2_printf("\r\nALIENTEK MiniSTM32������ ����ʵ��\r\n");
//				u2_printf("����ԭ��@ALIENTEK\r\n\r\n\r\n");
//			}
//			if(times%200==0)u2_printf("����������,�Իس�������\r\n");  
//			delay_ms(10);   
//		}		
		

		
	}
}

void System_Init(void)
{ 
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2
    delay_init();	    	 //��ʱ������ʼ��
    Target_Init();
}


void GPIO_Config_TFT(void)
{
   GPIO_InitTypeDef GPIO_InitStructure;  
	/* �������ݿڵ�GPIO�ܽ�ģʽ�����ģʽ*/
  	RCC_APB2PeriphClockCmd(RCC_GPIO_TFT, ENABLE); 					//ʹ��GPIOʱ��
  	GPIO_InitStructure.GPIO_Pin = D0|D1|D2|D3|D4|D5|D6|D7; //ʹ��PA0~PA7
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;				//GPIO���������ģʽ
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  	GPIO_Init(GPIO_TFT_DATA, &GPIO_InitStructure);  				//��ص�GPIO�ڳ�ʼ��
		
		/* ���ÿ��Ƶ�GPIO�ܽ�ģʽ�����ģʽ*/
  	RCC_APB2PeriphClockCmd(RCC_GPIO_CTRB, ENABLE); 					//ʹ��GPIOʱ��
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 |GPIO_Pin_12 |GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15| GPIO_Pin_7; //ʹ��PB8.9.10.11.12.13
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;				//GPIO���������ģʽ
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  	GPIO_Init(GPIO_CTRB, &GPIO_InitStructure);  						//��ص�GPIO�ڳ�ʼ��
		
		GPIO_ResetBits(GPIO_CTRB,GPIO_Pin_11);
}

//��ʱ��5�жϷ������




