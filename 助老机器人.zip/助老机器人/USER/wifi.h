#include "delay.h"
void smartstart()
  {
     USART1_SendString("AT+CWMODE=1\r\n");
     delay_ms(1500);
     USART1_SendString("AT+CWSTARTSMART\r\n");
     delay_ms(1500);
  }
void TCPconnect()
  {
    USART1_SendString("AT+CIPMUX=0\r\n");
    delay_ms(2500);
    USART1_SendString("AT+CIPMODE=0\r\n");
    delay_ms(2500);
    USART1_SendString("AT+CIPSTART=\"TCP\",\"115.29.109.104\",6582\r\n");
    delay_ms(2500);
    USART1_SendString("AT+CIPSEND=8\r\n");
    delay_ms(2500);
    USART1_SendString("Ready!\r\n");
  }
  void wifichu()
  {
    if(rx[0]=='r')
  {
        rxcnt++;
        if(rxcnt>5)
    {  
      
      if(rx[1]=='e'&&rx[4]=='y')
        {
          ch=1;
        }
        
          rxcnt=0;
    }
  }
 else
  {
    rxcnt=0;  
  }
if(rx1[0]=='s')
  {
    rxcnt1++;
  if(rxcnt1>13)
    { rxcnt1=0; 
      if(rx1[12]=='c')
        {
          ch1=1;
        }
        else
          {
           rxcnt1=0;  
          }
    }
  }
 else
  {
    rxcnt1=0;  
  }

  }
 void wifiorder()
  {
     
 if(rx2[0]=='+')
  {
   rxcnt2++;
   if(rxcnt2>1) 
    {
      
    rxcnt2=0;
   if(rx2[1]=='I')
    {
      ch3=1;
      rxcnt2=0;
    }
   else
  {
  rxcnt2=0;  
  } 
  }
  }
 else
  {
  rxcnt2=0;  
  } 
  
  if(ch3==1)
  { 
    
    if(SCI0DRL==':')
      {
        flag=1;
      }
      if(flag==1)
        {
        *(text+txcnt)=SCI0DRL; 
        txcnt++; 
        }
     if(SCI0DRL=='&') 
      { ch2=1;
        rxcnt3=0;
        ch3=0;
        flag=0;
        txcnt=0;
      }
  } 
  }
void wifisend(uchar len,uchar *txt)
  {
    uchar ge,shi;
    ge=len%10+0x30;
    shi=len/10%10+0x30;
    if(len<10)
      {
    USART1_SendString("AT+CIPSEND=");
    Usart1SendChar(len+0x30);
    USART1_SendString("\r\n"); 
    delay_ms(1500);
    USART1_SendString(txt); 
    USART1_SendString("\r\n");  
      }
    else
      {
     USART1_SendString("AT+CIPSEND=");
     Usart1SendChar(shi);
     Usart1SendChar(ge);
     USART1_SendString("\r\n");
     delay_ms(1500);
     USART1_SendString(txt); 
     USART1_SendString("\r\n");   
      }
  }
	