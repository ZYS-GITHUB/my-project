#include "TFT28.h"
#include "user_Config.h"   
void mainshow()
{
LCD_PutString(3,3,"�¶�:30C",Black,White);
LCD_PutString(123,3,"ʪ��:40H",Black,White);
LCD_PutString(3,23,"����:1000K",Black,White);
LCD_PutString(123,23,"PM2.5:100",Black,White);
LCD_PutString(3,43,"ȼ��:����",Black,White);
LCD_PutString(123,43,"ˮ��:����",Black,White);	
LCD_PutString(3,63,"�Ŵ�:����",Black,White);
LCD_PutString(123,63,"��Ա:����",Black,White);
LCD_PutString(3,83,"̨��:�ر�",Black,White);	
LCD_PutString(123,83,"����:�ر�",Black,White);
LCD_PutString(3,103,"ͨ��:�ر�",Black,White);
LCD_PutString(123,103,"����:�ر�",Black,White);
}
void wenshishow(u8 wenh,u8 wenl,u8 shih,u8 shil)
{
LCD_PutChar(43,3,wenh,Black,White);
LCD_PutChar(51,3,wenl,Black,White);
LCD_PutChar(163,3,shih,Black,White);
LCD_PutChar(171,3,shil,Black,White);	
}
void guang(u8 gq,u8 gb,u8 gs,u8 gg)
{
LCD_PutChar(43,23,gq,Black,White);
LCD_PutChar(51,23,gb,Black,White);	
LCD_PutChar(59,23,gs,Black,White);
LCD_PutChar(67,23,gg,Black,White);
}
void PM2(u8 pb,u8 ps,u8 pg)
{
LCD_PutChar(171,23,pb,Black,White);
LCD_PutChar(179,23,ps,Black,White);
LCD_PutChar(187,23,pg,Black,White);
}


void ranqi(u8 bit)
{
if(bit=='1')
{
LCD_PutString(43,43,"��",Black,White);
}
else
{
LCD_PutString(43,43,"��",Black,White);
}
}


void shuifa(u8 bit)
{
if(bit=='1')
{
LCD_PutString(163,43,"��",Black,White);
}
else
{
LCD_PutString(163,43,"��",Black,White);
}
}


void menchuang(u8 bit)
{
if(bit=='1')
{
LCD_PutString(43,63,"����",Black,White);
}
else
{
LCD_PutString(43,63,"�ر�",Black,White);
}
}


void renyuan(u8 bit)
{
if(bit=='1')
{
LCD_PutString(163,63,"��",Black,White);
}
else
{
LCD_PutString(163,63,"��",Black,White);
}
}


void taideng(u8 bit)
{
if(bit=='1')
{
LCD_PutString(43,83,"����",Black,White);
}
else
{
LCD_PutString(43,83,"�ر�",Black,White);
}
}
void fengshan(u8 bit)
{
if(bit=='1')
{
LCD_PutString(163,83,"����",Black,White);
}
else
{
LCD_PutString(163,83,"�ر�",Black,White);
}
}
void tongxin(u8 bit)
{
if(bit=='1')
{
LCD_PutString(43,103,"����",Black,White);
}
else
{
LCD_PutString(43,103,"�ر�",Black,White);
}
}
void qishan(u8 bit)
{
if(bit=='1')
{
LCD_PutString(163,103,"����",Black,White);
}
else
{
LCD_PutString(163,103,"�ر�",Black,White);
}
}
