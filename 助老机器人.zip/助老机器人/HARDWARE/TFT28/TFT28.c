/****************************************************************************************************  
??????:320x240TFT????,??TFT????,????,?????
****************************************************************************************************/

#include "stm32f10x.h"                   //STM32??????????,????
#include "user_Config.h"                  //???????,??????????,????????
#include "Ascii_8x16.h"                  //8x16????
#include "Chinese.h"                     //16x16???????

//**************?????????**************

extern unsigned int Device_code;

/****************************************************************************************************
//	????:	??
//	????:	count ??????
****************************************************************************************************/
void delayms(unsigned int count)
{
    int i,j;                                                                                
    for(i=0;i<count;i++)                                                                    
       {
	     for(j=0;j<0x640;j++);
       }                                                                                     
}



/****************************************************************************************************
//	????:	???
//	????:  DH ????16bits????8?
//              DL ????16bits????8?
****************************************************************************************************/
void Write_Cmd(unsigned char DH,unsigned char DL)
{
	CS_CLR;
	RS_CLR;
  RD_SET;
  RW_CLR;
	
		//??:???8??????16??????,??74HC573??IO??,????           
		GPIO_Write(DataPort,(u16)(DL | 0xff00));     	//??8????573???
		LE_SET;                   										//???
		LE_CLR;                   										//????,??573?Q7~Q0???           
		GPIO_Write(DataPort,(u16)(DH | 0xff00));			//??8????TFT

	/*
    //????16??????16?????,???IO??,????????????
    DataPort_L=DL; 
    DataPort_H=DH;
	*/

	RW_SET;
	CS_SET;
}

/****************************************************************************************************
//	????:	???(2*8bits)
//	????:  DH ????16bits????8?
//              DL ????16bits????8?
****************************************************************************************************/
void Write_Data(unsigned char DH,unsigned char DL)
{
	
	CS_CLR;
	RS_SET;

		//??:???8??????16??????,??74HC573??IO??,????           
		GPIO_Write(DataPort,(u16)(DL | 0xff00));     	//??8????573???
		LE_SET;                   										//???
		LE_CLR;                   										//????,??573?Q7~Q0???           
		GPIO_Write(DataPort,(u16)(DH | 0xff00));			//??8????TFT

	/*
    //????16??????16?????,???IO??,????????????
    DataPort_L=DL; 
    DataPort_H=DH;
	*/

	RW_CLR;
	RW_SET;
	CS_SET;
}

/****************************************************************************************************
//	????:	???(16?)
//	????:  y ????16bits??
****************************************************************************************************/
void  Write_Data_U16(unsigned int y)
{
	unsigned char m,n;
	m=y>>8;
	n=y;
	Write_Data(m,n);
}

/****************************************************************************************************
//	????:	?x?????y??
//	????:  x ??????? 16?
//              y ??????? 16?
****************************************************************************************************/
void  Write_Cmd_Data (unsigned char x,unsigned int y)
{
	unsigned char m,n;
	m=y>>8;
	n=y;
	Write_Cmd(0x00,x);
	Write_Data(m,n);
}

/****************************************************************************************************
//	????:	????
//  ????:  x0,y0 ????
//              x1,y1 ????
****************************************************************************************************/
void LCD_SetPos(unsigned int x0,unsigned int x1,unsigned int y0,unsigned int y1)
//void LCD_SetPos(int x0,int x1,int y0,int y1)
{

  Write_Cmd_Data(0x50,x0);  // Horizontal GRAM Start Address
  Write_Cmd_Data(0x51,x1);  // Horizontal GRAM End Address
  Write_Cmd_Data(0x52,y0);  // Vertical GRAM Start Address
  Write_Cmd_Data(0x53,y1);  // Vertical GRAM Start Address
  Write_Cmd_Data(0x20,x0);  // GRAM horizontal Address
  Write_Cmd_Data(0x21,y0);  // GRAM Vertical Address
  Write_Cmd (0x00,0x22);    // 0x0022,Start to Write Data to GRAM 
}

/****************************************************************************************************
//	????:	TFT??
//	????:	bColor ?????????
****************************************************************************************************/
void CLR_Screen(unsigned int bColor)
{
 unsigned int i,j;
 LCD_SetPos(0,240,0,320);													//320x240,???0??
 for (i=0;i<320;i++)
	{
	   for (j=0;j<240;j++)
	       Write_Data_U16(bColor);
	}
}

/****************************************************************************************************
//	????:	??Ascii??
//  ????:  x ???
//              y ???
//		        c ???????
//		        fColor ????
//		        bColor ??????
****************************************************************************************************/
void LCD_PutChar(unsigned int x, unsigned int y, char c, unsigned int fColor, unsigned int bColor)
{
 unsigned int i,j;
 LCD_SetPos(x,x+8-1,y,y+16-1);                    //????????
 for(i=0; i<16;i++) {                             //????16??,?????16??
		unsigned char m=Font8x16[(c-0x20)*16+i];  //??c????i????,c??0x20???Ascii????0~1f???
		for(j=0;j<8;j++) {                        //????8?,?????8?
			if((m&0x80)==0x80) {                  //????????1
				Write_Data_U16(fColor);           //????1,??????
				}
			else {
				Write_Data_U16(bColor);           //????0,??????
				}
			m<<=1;                                //??1?,??????
			}
		}
}


/****************************************************************************************************
//	????:	??16x16??
//  ????: x ???
//            y ???
//		        g ?????????
//		        fColor ????
//		        bColor ??????
****************************************************************************************************/

void Put16x16(unsigned short x, unsigned short  y, unsigned char g[2], unsigned int fColor,unsigned int bColor)
{
	unsigned int i,j,k;
	
	LCD_SetPos(x,  x+16-1,y, y+16-1);                       //????????

	for (k=0;k<64;k++)                                      //??64?,????????
	{ 
	  if ((ch16[k].GBK[0]==g[0])&&(ch16[k].GBK[1]==g[1]))   //???k?????????????g[2]??
	  { 
    	for(i=0;i<32;i++)                                   //????,???????????,????32??
		{
		  unsigned short m=ch16[k].hz16[i];                 	//??32?????i??
		  for(j=0;j<8;j++)                                  	//????8???
		   {                                                
			 if((m&0x80)==0x80) Write_Data_U16(fColor);     		//????????1,????1,??????
			 else              Write_Data_U16(bColor);      		//????0,??????
		     m<<=1;                                         	//??1?,??????
	       } 
		}
	  }  
    }	
}


void Put48x48(unsigned short x, unsigned short  y, unsigned char g[2], unsigned int fColor,unsigned int bColor)
{
	unsigned int i,j,k;

	LCD_SetPos(x,  x+48-1,y, y+48-1);                       //????????

	for (k=0;k<64;k++)                                      //??64?,????????
	{ 
	  if ((ch48[k].GBK[0]==g[0])&&(ch48[k].GBK[1]==g[1]))   //???k?????????????g[2]??
	  { 
    	for(i=0;i<288;i++)                                   //????,???????????,????32??
		{
		  unsigned short m=ch48[k].hz48[i];                 //??32?????i??
		  for(j=0;j<8;j++)                                  //????8???
		   {                                                
			 if((m&0x80)==0x80) Write_Data_U16(fColor);     //????????1,????1,??????
			 else              Write_Data_U16(bColor);      //????0,??????
		     m<<=1;                                         //??1?,??????
	       } 
		}
	  }  
    }	
}




void Put32x33(unsigned short x, unsigned short  y, unsigned char g[2], unsigned int fColor,unsigned int bColor)
{
	unsigned int i,j,k;

	LCD_SetPos(x,  x+32-1,y, y+33-1);                       //????????

	for (k=0;k<64;k++)                                      //??64?,????????
	{ 
	  if ((ch32[k].GBK[0]==g[0])&&(ch32[k].GBK[1]==g[1]))   //???k?????????????g[2]??
	  { 
    	for(i=0;i<132;i++)                                   //????,???????????,????32??
		{
		  unsigned short m=ch32[k].hz32[i];                 //??32?????i??
		  for(j=0;j<8;j++)                                  //????8???
		   {                                                
			 if((m&0x80)==0x80)
			 {                                                  //????????1,????1,??????
			  LCD_SetPos(x+i%4*8+j, x+i%4*8+j, y+i/4, y+i/4);      //????0,??????
			  Write_Data_U16(fColor);
			  }
		     m<<=1;                                         //??1?,??????
	       } 
		}
	  }  
    }
}


void Put24x24(unsigned short x, unsigned short  y, unsigned char g[2], unsigned int fColor,unsigned int bColor)
{
	unsigned int i,j,k;

	LCD_SetPos(x,  x+24-1,y, y+24-1);                       //????????

	for (k=0;k<64;k++)                                      //??64?,????????
	{ 
	  if ((ch24[k].GBK[0]==g[0])&&(ch24[k].GBK[1]==g[1]))   //???k?????????????g[2]??
	  { 
    	for(i=0;i<72;i++)                                   //????,???????????,????32??
		{
		  unsigned short m=ch24[k].hz24[i];                 //??32?????i??
		  for(j=0;j<8;j++)                                  //????8???
		   {                                                
			 if((m&0x80)==0x80) Write_Data_U16(fColor);     //????????1,????1,??????
			 else              Write_Data_U16(bColor);      //????0,??????
		     m<<=1;                                         //??1?,??????
	       } 
		}
	  }  
    }
}


/****************************************************************************************************
//	????:	????????
//  ????: x ???
//            y ???
//		        *s ???????,??LCD_PutString(24,16,"123Eee",White,Blue);??"123Eee"??????????????s.
//		        bColor ??????
****************************************************************************************************/
void LCD_PutString(unsigned short x, unsigned short y, unsigned char *s, unsigned int fColor, unsigned int bColor) 
{
	 unsigned char l=0;                            	//???????
	
     while(*s) 
	 {
		if( *s < 0x80)                             		//??s???????????????????128,????,??ASCII??
		    {
			 LCD_PutChar(x+l*8,y,*s,fColor,bColor);			//?????
		     s++;l++;                              		//???1,???1
			}
		else
		    {
			 Put16x16(x+l*8,y,(unsigned char*)s,fColor,bColor);		//?????
		     s+=2;l+=2;                                        	//????????2??,???2,??16x16?????2
			}
	 }
}


void LCD_PutString48x48(unsigned short x, unsigned short y, unsigned char *s, unsigned int fColor, unsigned int bColor) 
{
	 unsigned char l=0;                            //???????
     while(*s) 
	 {
		if( *s < 0x80)                             //??s???????????????????128,????,??ASCII??
		    {
			 LCD_PutChar(x+l*8,y,*s,fColor,bColor);//?????
		     s++;l++;                              //???1,???1
			}
		else
		    {
			 Put48x48(x+l*8,y,(unsigned char*)s,fColor,bColor);//?????
		     s+=2;l+=6;                                        //????????2??,???2,??16x16?????2
			}
	 }
}



void LCD_PutString32x33(unsigned short x, unsigned short y, unsigned char *s, unsigned int fColor, unsigned int bColor) 
{
	 unsigned char l=0;                            //???????
     while(*s) 
	 {
		if( *s < 0x80)                             //??s???????????????????128,????,??ASCII??
		    {
			 LCD_PutChar(x+l*8,y,*s,fColor,bColor);//?????
		     s++;l=l+5;                              //???1,???1
			}
		else
		    {
			 Put32x33(x+l*8,y,(unsigned char*)s,fColor,bColor);//?????
		     s+=2;l+=5;                                        //????????2??,???2,??16x16?????2
			}
	 }
}



void LCD_PutString24x24(unsigned short x, unsigned short y, unsigned char *s, unsigned int fColor, unsigned int bColor) 
{
	 unsigned char l=0;                            //???????
     while(*s) 
	 {
		if( *s < 0x80)                             //??s???????????????????128,????,??ASCII??
		    {
			 LCD_PutChar(x+l*8,y,*s,fColor,bColor);//?????
		     s++;l++;                              //???1,???1
			}
		else
		    {
			 Put24x24(x+l*8,y,(unsigned char*)s,fColor,bColor);//?????
		     s+=2;l+=4;                                        //????????2??,???2,??16x16?????2
			}
	 }
}


/****************************************************************************************************
//	????:	??????RGB??
//  ????: x0,y0 ????
//            x1,y1 ????
//		        Color  ????
****************************************************************************************************/

void Show_RGB (unsigned short x0,unsigned short x1,unsigned short y0,unsigned short y1,unsigned int Color)
{
	unsigned int i,j;
	
	LCD_SetPos(x0,x1,y0,y1);												//???????????,?????,????x0,x1,y0,y1???
	for (i=y0;i<=y1;i++)
	{
	   for (j=x0;j<=x1;j++)
	       Write_Data_U16(Color);
	}
}

/****************************************************************************************************
//	????:	TFT???
****************************************************************************************************/
void TFT_Initial(void)
{      
	RST_SET;    
	delayms(1);                    			// Delay 1ms 
	RST_CLR;  
	delayms(10);                   			// Delay 10ms            
	RST_SET;  
	delayms(50);                   			// Delay 50 ms  
  
	if(Device_code==0x9320)
     {

    //************* Start Initial Sequence **********//
	Write_Cmd_Data(0x00,0x0001);   		//Set the OSC bit as �1� to start the internal oscillator
  Write_Cmd_Data(0x01,0x0100);   	// set SS and SM bit
	Write_Cmd_Data(0x02,0x0700);   		// set 1 line inversion
	Write_Cmd_Data(0x03,0x1030);   		//set GRAM Write direction and BGR=1
  Write_Cmd_Data(0x04,0x0000);   	// Resize register
	Write_Cmd_Data(0x08,0x0202);   		// set the back porch and front porch
  Write_Cmd_Data(0x09,0x0000);   	// set non-display area refresh cycle ISC[3:0]
  Write_Cmd_Data(0x0A,0x0000);   	// FMARK function
  Write_Cmd_Data(0x0C,0x0000);   	// RGB interface setting
	Write_Cmd_Data(0x0D,0x0000);   		// Frame marker Position
  Write_Cmd_Data(0x0F,0x0000);   	// RGB interface polarity
  delayms(30);
	//*************Power On sequence ****************//
	Write_Cmd_Data(0x10, 0x16b0);   // SAP, BT[3:0], AP, DSTB, SLP, STB
	delayms(30);
	Write_Cmd_Data(0x11, 0x0007);   //Write final user�s setting values to VC bit
	Write_Cmd_Data(0x12, 0x013a);   // set Internal reference voltage
	Write_Cmd_Data(0x13, 0x1a00);   // VDV[4:0] for VCOM amplitude
  delayms(30);
  Write_Cmd_Data(0x29, 0x000c);   // Set VCM[5:0] for VCOMH
	delayms(30); // Delay 50ms

	// ----------- Adjust the Gamma Curve ----------//
	Write_Cmd_Data(0x0030, 0x0000);
	Write_Cmd_Data(0x0031, 0x0505);
	Write_Cmd_Data(0x0032, 0x0304);
	Write_Cmd_Data(0x0035, 0x0006);
	Write_Cmd_Data(0x0036, 0x0707);
	Write_Cmd_Data(0x0037, 0x0105);
	Write_Cmd_Data(0x0038, 0x0002);
	Write_Cmd_Data(0x0039, 0x0707);
	Write_Cmd_Data(0x003C, 0x0704);
	Write_Cmd_Data(0x003D, 0x0807);

	//------------------ Set GRAM area ---------------//
	Write_Cmd_Data(0x0050, 0x0000); // Horizontal GRAM Start Address
	Write_Cmd_Data(0x0051, 0x00EF); // Horizontal GRAM End Address
	Write_Cmd_Data(0x0052, 0x0000); // Vertical GRAM Start Address
	Write_Cmd_Data(0x0053, 0x013F); // Vertical GRAM Start Address
	Write_Cmd_Data(0x0060, 0x2700); // Gate Scan Line
	Write_Cmd_Data(0x0061, 0x0001); // NDL,VLE, REV
	Write_Cmd_Data(0x006A, 0x0000); // set scrolling line
  Write_Cmd_Data(0x20, 0x0000);   // GRAM horizontal Address
	Write_Cmd_Data(0x21, 0x0000);   // GRAM Vertical Address

	//-------------- Partial Display Control ---------//
	Write_Cmd_Data(0x0080, 0x0000);
	Write_Cmd_Data(0x0081, 0x0000);
	Write_Cmd_Data(0x0082, 0x0000);
	Write_Cmd_Data(0x0083, 0x0000);
	Write_Cmd_Data(0x0084, 0x0000);
	Write_Cmd_Data(0x0085, 0x0000);

	//-------------- Panel Control ---------//
  Write_Cmd_Data(0x90,0x0010);   //Frame Cycle Contral
	Write_Cmd_Data(0x92,0x0000);   //Panel Interface Contral
	Write_Cmd_Data(0x93,0x0003);   //Panel Interface Contral 3. 
	Write_Cmd_Data(0x95,0x0110);   //Frame Cycle Contral
	Write_Cmd_Data(0x97,0x0000);   // 
	Write_Cmd_Data(0x98,0x0000);   //Frame Cycle Contral.     

	//-------------- Display on ---------//
  Write_Cmd_Data(0x07,0x0173); 

	}

	else if(Device_code==0x1505 )
     {

    //************* Start Initial Sequence **********//
	Write_Cmd_Data(0x00,0x0001);   //Set the OSC bit as �1� to start the internal oscillator
  Write_Cmd_Data(0x01,0x0100);   // set SS and SM bit
	Write_Cmd_Data(0x02,0x0700);   // set 1 line inversion
	Write_Cmd_Data(0x03,0x1030);   //set GRAM Write direction and BGR=1
  Write_Cmd_Data(0x04,0x0000);   // Resize register
	Write_Cmd_Data(0x08,0x0202);   // set the back porch and front porch
  Write_Cmd_Data(0x09,0x0000);   // set non-display area refresh cycle ISC[3:0]
  Write_Cmd_Data(0x0A,0x0000);   // FMARK function
  Write_Cmd_Data(0x0C,0x0000);   // RGB interface setting
	Write_Cmd_Data(0x0D,0x0000);   // Frame marker Position
  Write_Cmd_Data(0x0F,0x0000);   // RGB interface polarity
  delayms(30);
	//*************Power On sequence ****************//
	Write_Cmd_Data(0x10, 0x16b0);   // SAP, BT[3:0], AP, DSTB, SLP, STB
	delayms(30);
	Write_Cmd_Data(0x11, 0x0007);   //Write final user�s setting values to VC bit
	Write_Cmd_Data(0x12, 0x013a);   // set Internal reference voltage
	Write_Cmd_Data(0x13, 0x1a00);   // VDV[4:0] for VCOM amplitude
  delayms(30);
  Write_Cmd_Data(0x29, 0x000c);   // Set VCM[5:0] for VCOMH
	delayms(30); // Delay 50ms

	// ----------- Adjust the Gamma Curve ----------//
	Write_Cmd_Data(0x0030, 0x0000);
	Write_Cmd_Data(0x0031, 0x0505);
	Write_Cmd_Data(0x0032, 0x0304);
	Write_Cmd_Data(0x0035, 0x0006);
	Write_Cmd_Data(0x0036, 0x0707);
	Write_Cmd_Data(0x0037, 0x0105);
	Write_Cmd_Data(0x0038, 0x0002);
	Write_Cmd_Data(0x0039, 0x0707);
	Write_Cmd_Data(0x003C, 0x0704);
	Write_Cmd_Data(0x003D, 0x0807);

	//------------------ Set GRAM area ---------------//
	Write_Cmd_Data(0x0050, 0x0000); // Horizontal GRAM Start Address
	Write_Cmd_Data(0x0051, 0x00EF); // Horizontal GRAM End Address
	Write_Cmd_Data(0x0052, 0x0000); // Vertical GRAM Start Address
	Write_Cmd_Data(0x0053, 0x013F); // Vertical GRAM Start Address
	Write_Cmd_Data(0x0060, 0x2700); // Gate Scan Line
	Write_Cmd_Data(0x0061, 0x0001); // NDL,VLE, REV
	Write_Cmd_Data(0x006A, 0x2700); // set scrolling line
  Write_Cmd_Data(0x20, 0x0000);   // GRAM horizontal Address
	Write_Cmd_Data(0x21, 0x0000);   // GRAM Vertical Address

	//-------------- Partial Display Control ---------//
	Write_Cmd_Data(0x0080, 0x0000);
	Write_Cmd_Data(0x0081, 0x0000);
	Write_Cmd_Data(0x0082, 0x0000);
	Write_Cmd_Data(0x0083, 0x0000);
	Write_Cmd_Data(0x0084, 0x0000);
	Write_Cmd_Data(0x0085, 0x0000);

	//-------------- Panel Control ---------//
  Write_Cmd_Data(0x90,0x0010);   //Frame Cycle Contral
	Write_Cmd_Data(0x92,0x0000);   //Panel Interface Contral
	Write_Cmd_Data(0x93,0x0003);   //Panel Interface Contral 3. 
	Write_Cmd_Data(0x95,0x0110);   //Frame Cycle Contral
	Write_Cmd_Data(0x97,0x0000);   // 
	Write_Cmd_Data(0x98,0x0000);   //Frame Cycle Contral.     

	//-------------- Display on ---------//
  Write_Cmd_Data(0x07,0x0173); 

	}

  else if(Device_code==0x9328)
     {

    //************* Start Initial Sequence **********//
	 Write_Cmd_Data(0x0001,0x0100);   //set SS and SM bit //??????  100
   Write_Cmd_Data(0x0002,0x0700);   //EOR=1 and B/C=1 to set the line inversion  //?????
   Write_Cmd_Data(0x0003,0x1030);   //set Entry Mode  //??????    1030
   Write_Cmd_Data(0x0004,0x0000);   //
   Write_Cmd_Data(0x00A4,0x0001);
   Write_Cmd_Data(0x0008,0x0202); // set the back porch and front porch
   Write_Cmd_Data(0x0009,0x0000); // set non-display area refresh cycle ISC[3:0]
   Write_Cmd_Data(0x000A,0x0000); // FMARK function
   Write_Cmd_Data(0x000C,0x0000); // RGB interface setting
   Write_Cmd_Data(0x000D, 0x0000); // Frame marker Position
   Write_Cmd_Data(0x000F, 0x0000); // RGB interface polarity



//*************Power On sequence ****************//
    Write_Cmd_Data(0x0010, 0x0000); // SAP, BT[3:0], AP, DSTB, SLP, STB 
    Write_Cmd_Data(0x0011, 0x0007); // DC1[2:0], DC0[2:0], VC[2:0]
    Write_Cmd_Data(0x0012, 0x0000); // VREG1OUT voltage
    Write_Cmd_Data(0x0013, 0x0000); // VDV[4:0] for VCOM amplitude 
    delayms(30);
    Write_Cmd_Data(0x0010, 0x1690); // SAP, BT[3:0], AP, DSTB, SLP, STB 
    Write_Cmd_Data(0x0011, 0x0227); // R11h=0x0221 at VCI=3.3V, DC1[2:0], DC0[2:0], VC[2:0]
    delayms(30);
    Write_Cmd_Data(0x0012, 0x001C); // External reference voltage= Vci;
    delayms(30); 
    Write_Cmd_Data(0x0013, 0x1800); // R13=1200 when R12=009D;VDV[4:0] for VCOM amplitude
    Write_Cmd_Data(0x0029, 0x001C); // R29=000C when R12=009D;VCM[5:0] for VCOMH
    Write_Cmd_Data(0x002B, 0x000D); // Frame Rate = 91Hz
    delayms(30);    
    Write_Cmd_Data(0x0020, 0x0000); // GRAM horizontal Address
    Write_Cmd_Data(0x0021, 0x0000); // GRAM Vertical Address
// ----------- Adjust the Gamma Curve ----------// 		 
	  Write_Cmd_Data(0x0030, 0x0007);
	  Write_Cmd_Data(0x0031, 0x0302);
    Write_Cmd_Data(0x0032, 0x0105);
	  Write_Cmd_Data(0x0035, 0x0206);
    Write_Cmd_Data(0x0036, 0x0808);	          
    Write_Cmd_Data(0x0037, 0x0206);
    Write_Cmd_Data(0x0038, 0x0504);
    Write_Cmd_Data(0x0039, 0x0007);
    Write_Cmd_Data(0x003C, 0x0105);
    Write_Cmd_Data(0x003D, 0x0808);
//------------------ Set GRAM area ---------------//
    Write_Cmd_Data(0x0050, 0x0000); // Horizontal GRAM Start Address
    Write_Cmd_Data(0x0051, 0x00EF); // Horizontal GRAM End Address
    Write_Cmd_Data(0x0052, 0x0000); // Vertical GRAM Start Address
	  delayms(30);
    Write_Cmd_Data(0x0053, 0x013F); // Vertical GRAM End Address
	  delayms(30);
    Write_Cmd_Data(0x0060, 0xA700); // Gate Scan Line
    Write_Cmd_Data(0x0061, 0x0001); // NDL,VLE, REV  
    Write_Cmd_Data(0x006A, 0x0000); // set scrolling line
//-------------- Partial Display Control ---------//
    Write_Cmd_Data(0x0080, 0x0000);
    Write_Cmd_Data(0x0081, 0x0000);
    Write_Cmd_Data(0x0082,0x0000); 
    Write_Cmd_Data(0x0083,0x0000); 
    Write_Cmd_Data(0x0084,0x0000); 
    Write_Cmd_Data(0x0085,0x0000); 
//-------------- Panel Control -------------------//        
    Write_Cmd_Data(0x0090, 0x0010);
    Write_Cmd_Data(0x0092, 0x0000);
    Write_Cmd_Data(0x0093, 0x0003);
    Write_Cmd_Data(0x0095, 0x0110);
    Write_Cmd_Data(0x0097, 0x0000);
    Write_Cmd_Data(0x0098, 0x0000);
    Write_Cmd_Data(0x0007, 0x0133); // 262K color and display ON

	}
}

/****************************************************************************************************
//	????:	??
//  ????: x,y ??????
//            color ????
****************************************************************************************************/
void Put_pixel(unsigned int x,unsigned int y,unsigned int color)
{
	LCD_SetPos(x,x,y,y);												//???????????,?????,????x0,x1,y0,y1???

	Write_Data_U16(color);      												//??????????
}

void Put_Line(unsigned int x0,unsigned int y0,unsigned int x,unsigned int y,unsigned int color)
{
   unsigned int i,j;
   float k;
	if(x==x0)
	  {
	    for(i=y0;i<=y;i++)
	    Put_pixel(x0,i,color);
	  }
	else
	  {
		 k=1.0*(y-y0)/(x-x0);
	  	for(i=x0;i<=x;i++)
		   {
		   	j=k*(i-x0)+y0;
			 Put_pixel(i,j,color);
		   }
		for(j=y0;j<=y;j++)
		   {
		   	 i=(j-y0)/k+x0;
			 Put_pixel(i,j,color);
		   } 
	  }

}
/*
//#include "pic.h"
#define width 80
#define high 60
void imagine(unsigned int fColor,unsigned int bColor)//�ڰ���Ƭ��������������
{
unsigned int i,j,k;
LCD_SetPos(0,width-1,0,high-1);//320x240
	for(i=0;i<=high;i++)
	{
	for(j=0;j<(width/8);j++)
		{
	unsigned char m=car[(i*(width/8))+j];
	for(k=0;k<8;k++) {                        //ѭ��д��8λ��һ���ֽ�Ϊ8λ
			if((m&0x80)==0x80) {                  //�ж����λ�Ƿ�Ϊ1
				Write_Data_U16(fColor);           //���λΪ1��д���ַ���ɫ
				}
			else {
				Write_Data_U16(bColor);           //���λΪ0��д�뱳����ɫ
				}
			m<<=1;                                //����1λ��׼��д��һλ
			}		
		}
	}
}

u16 rgbswitch(unsigned long rgb)
{
u16 color,red,green,blue;
red=((rgb>>16)&0x0000ff)>>3;
green=((rgb>>8)&0x0000ff)>>2;
blue=((rgb&0x0000ff)>>3);
color=(red<<11)|(green<<5)|(blue);	
	return color;
}
void photo(u16 x,u16 y)
{
unsigned int i,j;
LCD_SetPos(x,x+width-1,y,y+high-1);//320x240
	for(i=0;i<high;i++)
	{
	for(j=0;j<(3*width);j+=3)
		{
	unsigned long m=((unsigned long)(gImage_pic[(i*3*width)+j]))|((unsigned long)(gImage_pic[(i*3*width)+j+1])<<8)|((unsigned long)(gImage_pic[(i*3*width)+j+2])<<16);
  Write_Data_U16(rgbswitch(m));
				
		}
	}
}
*/


