
/*2.8?TFT???????*/
#define GPIO_TFT_DATA                   GPIOA    				         //???PA0~PA7
#define RCC_GPIO_TFT                    RCC_APB2Periph_GPIOA

#define GPIO_CTRB			              		GPIOB    				         //���ƿ�PB8~PA13
#define RCC_GPIO_CTRB    								RCC_APB2Periph_GPIOB

#define RS_CLR	        GPIO_ResetBits(GPIO_CTRB, GPIO_Pin_14)     //RS??
#define RS_SET	        GPIO_SetBits(GPIO_CTRB, GPIO_Pin_14)       //RS??

#define RW_CLR	        GPIO_ResetBits(GPIO_CTRB, GPIO_Pin_15)     //RW??
#define RW_SET	        GPIO_SetBits(GPIO_CTRB, GPIO_Pin_15)  		  //RW??

#define RD_CLR	        GPIO_ResetBits(GPIO_CTRB, GPIO_Pin_12)     //E??
#define RD_SET	        GPIO_SetBits(GPIO_CTRB, GPIO_Pin_12)       //E??

#define CS_CLR	        GPIO_ResetBits(GPIO_CTRB, GPIO_Pin_13)     //CS??
#define CS_SET	        GPIO_SetBits(GPIO_CTRB, GPIO_Pin_13)       //CS??

#define RST_CLR	        GPIO_ResetBits(GPIO_CTRB, GPIO_Pin_9)     //RST??
#define RST_SET	        GPIO_SetBits(GPIO_CTRB, GPIO_Pin_9)       //RST??

#define LE_CLR	        GPIO_ResetBits(GPIO_CTRB, GPIO_Pin_8)     //LE??
#define LE_SET	        GPIO_SetBits(GPIO_CTRB, GPIO_Pin_8)       //LE??

#define DataPort        GPIOA                     								//PA?????

#define D0              GPIO_Pin_0             										//D0???GPIO??
#define D1              GPIO_Pin_1																//D1???GPIO??
#define D2              GPIO_Pin_2  															//D2???GPIO??
#define D3							GPIO_Pin_3																//D3???GPIO??
#define D4					    GPIO_Pin_4             										//D4???GPIO??
#define D5				      GPIO_Pin_5																//D5???GPIO??
#define D6				     	GPIO_Pin_6  															//D6???GPIO??
#define D7				     	GPIO_Pin_7		


//D7???GPIO??

#define RCC_GPIO_DS18B20                RCC_APB2Periph_GPIOC    //?�?�PC13
#define GPIO_DS18B20                    GPIOC                   //�1�?�?GPIO?aPC
#define GPIO_Pin_DS18B20 								GPIO_Pin_13

#define DQ_CLR	        GPIO_ResetBits(GPIO_DS18B20,GPIO_Pin_DS18B20)	    //??���???
#define DQ_SET	        GPIO_SetBits(GPIO_DS18B20,GPIO_Pin_DS18B20)	      //????�???
#define DQ_R	          GPIO_ReadInputDataBit(GPIO_DS18B20, GPIO_Pin_DS18B20)		      //?�???

/*????-????*/

#define White          0xFFFF           													//??????
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0

/*?????*/
void RCC_Configuration(void);
void NVIC_Configuration(void);
//void Delay(vu32 nCount);



