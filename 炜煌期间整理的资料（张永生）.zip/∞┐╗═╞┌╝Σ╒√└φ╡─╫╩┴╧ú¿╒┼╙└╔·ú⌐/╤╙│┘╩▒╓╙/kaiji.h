#ifndef __KAIJI_H__
#define __KAIJI_H__ 
void kaiji()
{   uint i;
	CLR_Screen(White);
	for(i=0;i<=20;i++)
	{ delayms(200);
	  LCD_PutString56(140,60-i,"��",Red,White);
	 }
	 xian(168,68,28,20,Yellow);
	 CH(120,138,65,10,0xabcd);
	 LCD_PutString32(104,130,"��",Blue,White);
	 for(i=0;i<=24;i++)
	 {delayms(200);
	 LCD_PutString32(i,130,"���չ�",Black,White);
	 LCD_PutString32(144-i,130,"ҵ��ѧ",Black,White);
	  
	 }
	 for(i=0;i<=40;i++)
	 {
	 Put_Line(115,158+i,120,158+i,Blue);  
	 }	delayms(20);
	 for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(115,158+i,120,158+i,White);  
	 }
	 for(i=110;i>=30;i--)
	 { delayms(50);
	 LCD_PutString29(i,175,"����ɳ",Blue,White);
	 }
	 for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(60+i,180,60+i,185,Blue);  
	 }
	  for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(60+i,180,60+i,185,White);  
	 }
	 LCD_PutString29(80,175,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(115,175,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(150,175,"��",Red,White);
	 delayms(500);
	 for(i=0;i<=100;i++)
	 { delayms(20);
	 Put_Line(80+i,215,80+i,225,Blue2);  
	 }
	 delayms(500);
	 for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(80+i,244,80+i,249,Blue);  
	 }
	  for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(80+i,244,80+i,249,White);  
	 }
	 LCD_PutString29(95,235,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(130,235,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(165,235,"��",Red,White);
	 delayms(500);
	 Show_bian(0,0,240,320,20,Green);
	 }
	 #endif