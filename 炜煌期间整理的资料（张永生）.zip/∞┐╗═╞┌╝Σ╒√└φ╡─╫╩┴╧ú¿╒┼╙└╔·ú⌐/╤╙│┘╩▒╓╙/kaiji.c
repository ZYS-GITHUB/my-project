#include<reg52.h>    //������Ƭ��ͷ�ļ�
#include"NBCTFT.h"   //����TFT����ͷ�ļ�
#include <math.h>

//******************ȫ�ֱ���***************************

#define White          0xFFFF   //LCD color
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0
uint code a[]={0x07E0,0xFFE0,0xF81F,0x7FFF,0xF800,0x051F,0x0000,0x001F};
extern void delayms(unsigned int count);
void zhuanchang()
{float j;
int i;
  CLR_Screen(White);
	 Show_RGB(0,240,0,64,Blue);  
	  LCD_PutString32(30,10,"��ί��ʦ��",Black,Blue);
	  for(i=64;i<=320;i+=16)
	  {
	  LCD_PutChar(5,i,'*',a[rand()%8],White);
	  LCD_PutChar(219,i,'*',a[rand()%8],White);
	   }
	   
	  
	   LCD_PutString32(105,144,"��",Blue,White);
	   for(j=0;j<=3;j+=0.05)
	   duobian(120,160,(int)j*40,6,Red,(int)(j*100)%75);
	    delayms(5000); 
	   Show_RGB(0,240,64,320,White);
	   for(i=64;i<=320;i+=16)
	  {
	  LCD_PutChar(5,i,'*',a[rand()%8],White);
	  LCD_PutChar(219,i,'*',a[rand()%8],White);
	   }
	   LCD_PutString32(105,144,"��",Blue,White);
	  for(j=0;j<=3;j+=0.05)
	   duobian(120,160,(int)j*40,4,Blue,(int)(j*100)%75);
	    delayms(5000);
	    Show_RGB(0,240,64,320,White);
		for(i=64;i<=320;i+=16)
	  {
	  LCD_PutChar(5,i,'*',a[rand()%8],White);
	  LCD_PutChar(219,i,'*',a[rand()%8],White);
	   }
	   LCD_PutString32(105,144,"��",Blue,White);  
	   for(j=0;j<=3;j+=0.05)
	   duobian(120,160,(int)j*40,3,Green,(int)(j*100)%75);	   
	  delayms(5000);
}
void kaiji()
{uint i;
 CLR_Screen(White);
	for(i=0;i<=20;i++)
	{ delayms(200);
	  LCD_PutString56(140,60-i,"��",Red,White);
	 }
	 xian(168,68,28,20,Yellow);
	 CH(120,138,65,10,0xabcd);
	 LCD_PutString32(104,130,"��",Blue,White);
	 for(i=0;i<=24;i++)
	 {delayms(200);
	 LCD_PutString32(i,130,"���չ�",Black,White);
	 LCD_PutString32(144-i,130,"ҵ��ѧ",Black,White);
	  
	 }
	 for(i=0;i<=40;i++)
	 {
	 Put_Line(115,158+i,120,158+i,Blue);  
	 }	delayms(20);
	 for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(115,158+i,120,158+i,White);  
	 }
	 for(i=110;i>=30;i--)
	 { delayms(50);
	 LCD_PutString29(i,175,"����ɳ",Blue,White);
	 }
	 for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(60+i,180,60+i,185,Blue);  
	 }
	  for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(60+i,180,60+i,185,White);  
	 }
	 LCD_PutString29(80,175,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(115,175,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(150,175,"��",Red,White);
	 delayms(500);
	 for(i=0;i<=100;i++)
	 { delayms(20);
	 Put_Line(80+i,215,80+i,225,Blue2);  
	 }
	 delayms(500);
	 for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(80+i,244,80+i,249,Blue);  
	 }
	  for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(80+i,244,80+i,249,White);  
	 }
	 LCD_PutString29(95,235,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(130,235,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(165,235,"��",Red,White);
	 delayms(500);
	 Show_bian(0,0,240,320,20,Green);
}