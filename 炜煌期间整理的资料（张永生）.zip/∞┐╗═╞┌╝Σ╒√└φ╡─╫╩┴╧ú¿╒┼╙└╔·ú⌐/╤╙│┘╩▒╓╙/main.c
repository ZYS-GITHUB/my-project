#include<reg52.h> 
#include"NBCTFT.h"
#include <math.h>
#define White          0xFFFF   
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0
extern unsigned int Device_code;
uint miao=0,fen=0,shi=0;
int temp=0,temp1=0,temp2=0;
bit flag=0;
bit flag1=0;     
void delay1s(void)
{
 uchar a,b,c;
 for(c=205;c>0;c--)
  for(b=116;b>0;b--)
  for(a=9;a>0;a--);
}
void yuan()
{
 float j;
 for(j=0;j<=6.28;j+=0.01)
 {
  Put_pixel((int)(120+70*cos(j)),(int)(160+70*sin(j)),Red);
 }
 xian(120,160,60,10,Blue);
}
void shizhong(int miao1,int fen1,int shi1,int color,int color1,int color2)
{
Put_Line(120,160,(int)(120+50*cos(1.57+(miao1*0.017))),(int)(160-50*sin(1.57+(miao1*0.017))),color);
Put_Line(120,160,(int)(120+40*cos(1.57+(fen1*0.017))),(int)(160-40*sin(1.57+(fen1*0.017))),color1);
Put_Line(120,160,(int)(120+30*cos(1.57+(shi1*0.017))),(int)(160-30*sin(1.57+(shi1*0.017))),color2);
}
void yunxing()
{
delay1s();
		miao++;
		if(miao==60)
		{
		 miao=0;
		 flag=1;
		}
		if(flag==1)
		{
		 fen++;
		 flag=0;
		} 
		if(fen==60)
		{
		 fen=0;
		 flag1=1;
		}
		if(flag1==1)
		{
		 shi++;
		 flag1=0;
		 }
}
void main()
{        		
	   Device_code=0x9328;                       
       TFT_Initial();
	    CLR_Screen(White); 
	    yuan();                   	 
  while(1)                                
      {	
	  
	    
		yunxing();
		shizhong(miao,fen,shi,Black,Black,Black);
		if(temp!=miao)
		{
		shizhong(temp,fen,shi,White,Black,Black);
		temp=miao;
		}
		if(temp1!=fen)
		{
		shizhong(miao,temp1,shi,Black,White,Black);
		temp1=fen;
		}
		if(temp2!=shi)
		{
		shizhong(miao,fen,temp2,Black,Black,White);
		temp2=shi;
		}

	  }
 
  }



