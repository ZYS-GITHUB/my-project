
#include<reg52.h>    //������Ƭ��ͷ�ļ�
#include"NBCTFT.h"   //����TFT����ͷ�ļ�
#include <math.h>
//******************ȫ�ֱ���***************************

#define White          0xFFFF   //LCD color
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0
#define SCRW 240
#define SCRH 320
unsigned int Device_code;      //TFT����IC�ͺ�

//**************�����ⲿ�����ͱ���********************
extern void delayms(unsigned int count);


//================================================================================================
//	�������ƣ�	������
//	ʵ�ֹ��ܣ�	����TFTʵ�ֺ��֣��ַ���ʾ.
//	������		��
//	����ֵ��	��
//================================================================================================
main()
{
       int i,n=0;
	   uchar y='4';
	   float j;
	   Device_code=0x9328;                //TFT����IC�ͺ�
       
       TFT_Initial();                     //��ʼ��LCD	 
	  
  while(1)                                //ѭ��
      {
	   CLR_Screen(White);
	   for(i=6;i>=3;i--)
	   {
	   CLR_Screen(White);
	   y--;
	   LCD_PutChar(120,155,y,Red,White); 
	   for(j=0;j<=3.1415;j+=0.05)
	   duobian(120,160,(int)j*30,i,63+(int)j*30,(int)7*(j*10-2),(int)63-2*j*10,(int)(j*100)%90);
	   }
	   delayms(5000);
	  for(i=0;i<=240;i++)
	  {
	  if(i>=0&&i<=160)
	  {
	   
	    Put_Line1(i,160,0,160-i,Green);
		Put_Line1(i,160,0,160+i,Green);
	   }
	   
	  if(i>160&&i<=240)
	  {
	 
	    Put_Line1(i,160,i-160,0,Green);
		Put_Line1(i,160,i-160,320,Green);
	   } 
	   

	   }
	   LCD_PutString64x64(120-32,160-32,"��",Yellow,Green);
	   LCD_PutString64x64(10,160-32,"��",Red,Green);
	   for(i=0;i<=160;i++)
	   {
	   	Put_Line(240,i,240-i,0,0x7FFF);
		Put_Line(240,320-i,240-i,320,0x7FFF);
	   }
	   LCD_PutString40x37(21,139,"��",Yellow,Red);
	   LCD_PutString40x37(98,139,"ʼ",Red,Yellow);
	    delayms(5000);
	   CLR_Screen(White); 
	   Show_RGB(0,240,0,64,Blue);
	   for(i=0;i<=176;i+=16)
	   {
	   LCD_PutString(45,18,"��",Red,Blue);
	  
	   if(i>0&&i<=16)
	   { delayms(400);
	   LCD_PutString(45,18,"��",Red,Blue);
	   LCD_PutString(65+i,18,"��",Red,Blue);
	   }
	   else if(i<=32)
	   { delayms(400);
	   	 LCD_PutString(45,18,"��",Red,Blue);
		 LCD_PutString(65+i,18,"��",Red,Blue);
	     LCD_PutString(45+i,18,"�",Yellow,Blue);
	   }
	   else if(i<=48)
	   { delayms(400);
	   	 LCD_PutString(45,18,"��",Red,Blue);
		 LCD_PutString(65+i,18,"��",Red,Blue);
	     LCD_PutString(45+i,18,"��",Yellow,Blue);
	   }
	   else if(i<=64)
	   { delayms(400);
	   	 LCD_PutString(45,18,"��",Red,Blue);
		 LCD_PutString(65+i,18,"��",Red,Blue);
	     LCD_PutString(45+i,18,"��",Yellow,Blue);
	   }
	   else if(i<=5*16)
	   { delayms(400);
	   	 LCD_PutString(45,18,"��",Red,Blue);
		 LCD_PutString(65+i,18,"��",Red,Blue);
	     LCD_PutString(45+i,18,"Ƭ",Yellow,Blue);
	   }
	   else if(i<=(6*16))
	   { delayms(400);
	   	 LCD_PutString(45,18,"��",Red,Blue);
		 LCD_PutString(65+i,18,"��",Red,Blue);
	     LCD_PutString(45+i,18,"��",Yellow,Blue);
	   }
	   else if(i<=(7*16))
	   { delayms(400);
	   	 LCD_PutString(45,18,"��",Red,Blue);
		 LCD_PutString(65+i,18,"��",Red,Blue);
	     LCD_PutString(45+i,18,"ʡ",Yellow,Blue);
	   }
	   else if(i<=(8*16))
	   { delayms(400);
	   	 LCD_PutString(45,18,"��",Red,Blue);
		 LCD_PutString(65+i,18,"��",Red,Blue);
	     LCD_PutString(45+i,18,"��",Yellow,Blue);
	   }
	   else if(i<=(9*16))
	   { delayms(400);
	   	 LCD_PutString(45,18,"��",Red,Blue);
		 LCD_PutString(65+i,18,"��",Red,Blue);
	     
	   }
	  
	   }
	   CH(120,138,65,10,0xaccd);
	  
	   huayuan(120,128,30,0xf800);
	   LCD_PutString40x37(64,170,"������",Red,White);
	   for(j=0;j<=240;j++)
	   {	   	
		Put_Line1(j,300,j,315,Green);
	   }
	   for(i=0;i<=15;i++)
	   { 
	   delayms(500);
	   LCD_PutString32x27(27+i,200,"����",Black,White);

	   LCD_PutString32x27(195-i,200,"������",Black,White);

	   }
	  
	   Show_bian(0,0,240,320,12,0xabce);
	   
	  

	   while(1);
	  }
 	  
  }



