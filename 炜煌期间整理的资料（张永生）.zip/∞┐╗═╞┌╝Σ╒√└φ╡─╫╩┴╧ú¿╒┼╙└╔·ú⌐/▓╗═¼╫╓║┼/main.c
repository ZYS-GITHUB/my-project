#include<reg52.h>    
#include"NBCTFT.h"  
#include<stdio.h>
#include<math.h>
#define White          0xFFFF  
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0
#define SCRW 240
#define SCRH 360
#define PI 3.141592
extern unsigned int Device_code;      
extern void delayms(unsigned int count);
uint a[7]={0xF800,0xFFE0,0x7FFF,0x07E0,0x001F,0xF81F,0xFFFF};
void CH(int x0,int y0,int r,int k,uint color)
{
	float j;
	int x,y,m;
	for(j=3.141;j<6.31;j=j+0.01)
	{	for(m=r;m<=r+k;m++)
		{x=(int)m*cos(j)+x0;
		y=(int)m*sin(j)+y0;
		Put_pixel(x,y,color);}
	} 
}


main()
{	   
       unsigned int i,j;
	   Device_code=0x9320;               
       TFT_Initial();                    
 while(1)                            
      {
	   	CLR_Screen(Red);
	   Show_RGB(0,240,0,64,Blue);
 	   LCD_PutString37(50,20," �� �� С ",Yellow,Blue);
	   LCD_PutString32(55,70," �� �� �� ",White,Red);
	   LCD_PutString27(58,108," �� �� �� ",White,Red);
	   LCD_PutString21(61,148," �� �� �� ",White,Red);
	   LCD_PutString(68,180,"   �� �� �� ",White,Red);
	   for(i=25;i<=95;i+=10)
	   {CH(SCRW/2,SCRH,i,10,a[(i-25)/10]);}
	   for(j=300;j>=70;j-=10)
		{  delayms(500);
		 LCD_PutChar(16,j,'*',a[((j/10)-16)%7],Red);
		 LCD_PutChar(220,j,'*',a[((j/10)-16)%7],Red);
		}
	  
 	   while(1);
	   
	  }
 
  }



