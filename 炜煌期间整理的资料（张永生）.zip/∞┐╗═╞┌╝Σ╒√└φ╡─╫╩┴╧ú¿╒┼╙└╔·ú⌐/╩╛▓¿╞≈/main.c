#include<reg52.h>    //������Ƭ��ͷ�ļ�
#include"NBCTFT.h"   //����TFT����ͷ�ļ�


//******************ȫ�ֱ���***************************

#define White          0xFFFF   //LCD color
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0

extern uchar Read_AD(uchar chn);

unsigned int Device_code;      

int cnt;

void init()
{
IE=0x82;
TMOD=0x01;
TH0=0xff;
TL0=0xf0;
TR0=1;

}
//================================================================================================
//	�������ƣ�	������
//	ʵ�ֹ��ܣ�	����TFTʵ�ֺ��֣��ַ���ʾ.
//	������		��
//	����ֵ��	��
//================================================================================================
main()
{
        
		int volt,xz=31,volt1,xz1=31,i,ca,flag=0;
	   Device_code=0x9328;                       
       TFT_Initial(); 
	   init();  
	   CLR_Screen(White);                  //��ʼ��LCD	 
	 Put_Line(30,50,30,280,Black);
	 Put_Line(30,270,220,270,Black);
  while(1)                                //ѭ��
      {	

	   volt=Read_AD(0);
	 if(cnt!=0)
	 {cnt=0;  
	   
	   
	   xz+=10;
	   if(flag==1)
	   {
	   	ca=xz-11;
	   }
	   else
	   ca=xz;
	  for(i=1;i<=11;i++)
	  { 
	   Put_Line(ca+i,269,ca+i,0,White);
	   }
	   if(xz!=xz1||volt!=volt1)
	   {
	   	Put_Line(xz,volt,xz1,volt1,Red);
		xz1=xz;
		volt1=volt;
	   }
	   if (xz>=221)
	   {xz=31;
	   	xz1=31;
		
		flag=1;
	   }
	  }
	  
	 
	  
	  }
 	  }
  
void tf0(void) interrupt 1
{	   
TH0=0xff;
TL0=0xf0;
 cnt++;
}


