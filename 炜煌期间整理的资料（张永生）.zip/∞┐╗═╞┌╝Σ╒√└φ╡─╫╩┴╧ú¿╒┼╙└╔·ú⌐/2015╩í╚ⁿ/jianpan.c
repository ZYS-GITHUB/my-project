#include <reg52.h>
sbit s17=P1^7;
sbit s18=P1^6;
sbit s19=P1^5;
sbit s20=P1^4;
sbit s21=P1^3;
sbit beep=P3^4;
extern void delayms(unsigned int count);
unsigned char data dis1[4]={0x00,0x00,0x00,0x00};
unsigned char data dis2[4]={0x00,0x00,0x00,0x00};
int mood=-1;
//////////////////////////////////////////
//����ɨ��
//////////////////////////////////////////
int jianpan()
{
  if(s17==0)
  {
   delayms(50);
   while(s17==0);
   return (17);
  }
  if(s18==0)
  {
   delayms(50);
   while(s18==0);
   return (18);
  }
  if(s19==0)
  {
   delayms(50);
   while(s19==0);
   return (19);
  }
  if(s20==0)
  {
   delayms(50);
   while(s20==0);
   return (20);
  }
  if(s21==0)
  {
   delayms(50);
   while(s21==0);
   return (21);
  }
}
//////////////////////////////////////////////////
//����������
////////////////////////////////////////////////
void setgao(int *shu,int *shu1,int *flag)
{
 int i;
 i=jianpan();
 switch(i)
 {
  case 19:  {  (*flag)++;if((*flag)==1){mood=0;}if((*flag)==2){mood=1;}  if((*flag)==3)  {   (*flag)=0;mood=-1;  }  };break;
  case 17:  {if(mood==0){if((*shu)<=25&&(*shu)>10){(*shu)--;(*shu1)=(*shu1);}else{(*shu)=10;(*shu1)=(*shu1);}}if(mood==1){if((*shu1)<=45&&(*shu1)>30){(*shu)=(*shu);(*shu1)--;}else{(*shu1)=30;(*shu)=(*shu);}}};break;
  case 21:  {if(mood==0){if((*shu)<25&&(*shu)>=10){(*shu)++;(*shu1)=(*shu1);}else{(*shu)=25;(*shu1)=(*shu1);}}if(mood==1){if((*shu1)<45&&(*shu1)>=30){(*shu)=(*shu);(*shu1)++;}else{(*shu1)=45;(*shu)=(*shu);}}};break;
  case 20:{(*flag)=4;};break;
  case 18:{(*flag)=0;};break;
  default:break;
 }
}
/////////////////////////////////////////////
//��������Ļ�������
/////////////////////////////////////////////
void chulijianpan(int H,int L)
{
 dis1[0]=((int)H/10)+0x30;
 dis1[1]=((int)H%10)+0x30;
 dis1[2]=((int)L/10)+0x30;
 dis1[3]=((int)L%10)+0x30;
}
//////////////////////////////
//����
////////////////////////////
void beeps(int *x0,int *x1,int *x2)
{if((*x0)-(*x1)<0||(*x2)-(*x0)<0)
 beep=0; 
 else
 beep=1;
}
////////////////////////////
//��ֵ��Ļ�������
//////////////////////
void chulizuizhi(int H,int L)
{
 dis2[0]=((int)H/10)+0x30;
 dis2[1]=((int)H%10)+0x30;
 dis2[2]=((int)L/10)+0x30;
 dis2[3]=((int)L%10)+0x30;
}