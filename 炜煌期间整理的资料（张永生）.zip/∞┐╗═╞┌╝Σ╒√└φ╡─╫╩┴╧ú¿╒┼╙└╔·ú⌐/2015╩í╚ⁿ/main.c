/*s17~s21�ֱ����P1^7~P1^3�ڣ�eeprom��sda��P3^6,scl��P3^7,18b20��P2^7.���ϲ���*/

#include<reg52.h>   
#include"NBCTFT.h"  
#include <math.h>
#define White          0xFFFF   
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0

     
extern void delayms(unsigned int count);
extern void kaiji();
extern void biao(void);
extern void show(int di,int gao);
extern void zhizhen(int re,int bcolor);
extern int re1;
extern uint get_temp();
extern int jianpan();
extern void setgao(int *shu,int *shu1,int *flag);
extern uchar data dis[3];
extern uchar data dis1[4];
extern unsigned char data dis2[4];
extern void chulijianpan(int H,int L);
extern void chuli(uint temperature);
extern void zuobiao();
extern void beeps(int *x0,int *x1,int *x2);
extern int flag9=0;	
extern void read_nword(uchar device_add,uchar word_add,uchar n,uchar *date);   
extern void write_nword(uchar device_add,uchar word_add,uchar n,uchar *date); 
extern void compare(int *p,int *n,int *m);
extern uchar temp1[8]; 
extern void chulizuizhi(int H,int L);

unsigned int Device_code;
int gaox=40,dix=15;
int re=0,retemp;
int cnt=0;
uchar mamin[3]={0x00,0x00,0x00};
void init()
{
IE=0x82;
TMOD=0x01;
TH0=0xb8;
TL0=0x00;
TR0=1;
}
main()
{     int i,xz=31,xz1=31,ca,start=0,dix1,gaox1,reliang,chucun=0;
	   Device_code=0x9328;                       
       TFT_Initial();
	  
	        while(1)                                
     { 
	   CLR_Screen(White);	
	   read_nword(0xa0,0,3,temp1);
	   chulizuizhi(temp1[1],temp1[2]);
	  LCD_PutChar16x24(15,5,'M',Red,White);
	  LCD_PutChar16x24(31,5,'i',Red,White);
	  LCD_PutChar16x24(47,5,'n',Red,White);
	  LCD_PutChar16x24(15,30,'M',Red,White);
	  LCD_PutChar16x24(31,30,'a',Red,White);
	  LCD_PutChar16x24(47,30,'x',Red,White);
	   LCD_PutChar16x24(120,5,dis2[0],Red,White);
	   LCD_PutChar16x24(136,5,dis2[1],Red,White);
	   LCD_PutChar16x24(120,30,dis2[2],Red,White);
	   LCD_PutChar16x24(136,30,dis2[3],Red,White);
	   delayms(5000);
	 kaiji();
	 delayms(1000);
	 while(1)
	 {
	 while(flag9==0)
	 {
	 CLR_Screen(White);
	 biao();
	 show(dix,gaox);
	 while(flag9==0)
	 {
	 setgao(&dix,&gaox,&flag9);
	 if(dix1!=dix||gaox1!=gaox)
	 {
	 show(dix,gaox);
	 dix1=dix;gaox1=gaox;
	 }
	 re=get_temp();
	 reliang=re*0.0625+0.05;
	 beeps(&reliang,&dix,&gaox);
	 if(chucun==0)
	 {
	 mamin[0]=reliang;
	 mamin[1]=reliang;
	 mamin[2]=reliang;
	 chucun=1;
	 }
	 else
	 { mamin[0]=reliang;}
	 compare(&mamin[0],&mamin[1],&mamin[2]);
	 write_nword(0xa0,0,3,mamin);
	 if((re*0.0625+0.05)>=dix&&(re*0.0625+0.05)<=gaox)
	 zhizhen((re*0.0625+0.05),Green);
	 else if((re*0.0625+0.05)<dix)
	 zhizhen((re*0.0625+0.05),Blue);
	  else if((re*0.0625+0.05)>gaox)
	  zhizhen((re*0.0625+0.05),Red);
	 chuli(re);
	 LCD_PutChar16x24(82,272,dis[1],Red,White);
	 LCD_PutChar16x24(98,272,dis[0],Red,White);
	 LCD_PutChar16x24(114,272,'.',Red,White);
	 LCD_PutChar16x24(130,272,dis[2],Red,White);
	 }
	  }
	while(flag9==1)
	{
	 CLR_Screen(White);
	 if(flag9!=1)break;
	 while(flag9==1)
	 { 
	  LCD_PutString32(5,5,"�������ޣ�",Red,White);
	  LCD_PutString32(5,40,"�������ޣ�",Blue,White);
	  setgao(&dix,&gaox,&flag9);
	  chulijianpan(dix,gaox);
	  LCD_PutChar16x24(141,7,dis1[0],Red,White);
	  LCD_PutChar16x24(157,7,dis1[1],Red,White);
	  LCD_PutChar16x24(141,40,dis1[2],Red,White);
	  LCD_PutChar16x24(157,40,dis1[3],Red,White);
	 }
	}
	while(flag9==2)
	{
	 CLR_Screen(White);
	 if(flag9!=2)break;
	 while(flag9==2)
	 { 
	  LCD_PutString32(5,5,"�������ޣ�",Blue,White);
	  LCD_PutString32(5,40,"�������ޣ�",Red,White);
	  setgao(&dix,&gaox,&flag9);
	  chulijianpan(dix,gaox);
	  LCD_PutChar16x24(141,7,dis1[0],Red,White);
	  LCD_PutChar16x24(157,7,dis1[1],Red,White);
	  LCD_PutChar16x24(141,40,dis1[2],Red,White);
	  LCD_PutChar16x24(157,40,dis1[3],Red,White);
	 }
	}
	while(flag9==4)
	{ init();
	 CLR_Screen(White);
	 zuobiao();
	 if(flag9!=4)break;
	 while(flag9==4)
	 { 
	 setgao(&dix,&gaox,&flag9);
	 reliang=(get_temp())*0.0625+0.05;
	 beeps(&reliang,&dix,&gaox);
	 re=(int)(50+4*(50-((get_temp())*0.0625+0.05)));
	  if(cnt>=50)
	  {
	  	cnt=0;
		xz+=10;
		if(start==1)
		{
		 ca=xz-11;
		}
		else
		ca=xz;
		for(i=1;i<=11;i++)
		{
		 Put_Line(ca+i,279,ca+i,0,White);
		 Put_Line(30,50+4*(50-dix),205,50+4*(50-dix),Black);
		 
		 Put_Line(30,50+4*(50-gaox),205,50+4*(50-gaox),Black);
		 Show_RGB(30,200,281,320,White);
		}
		if(xz!=xz1||re!=retemp)
	   {
	   	Put_Line(xz,re,xz1,retemp,Red);
		xz1=xz;
		retemp=re;
	   }
	   if (xz>=221)
	   {xz=31;
	   	xz1=31;		
		start=1;
	   }
	  }
	 }
	}//flag==4

	 }//while(1)��������ǰ
	
	  }//while(1)��ѭ��
 
  }
void tf0(void) interrupt 1
{	   
TH0=0xb8;
TL0=0x00;
cnt++;
}

