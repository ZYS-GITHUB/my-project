#include<reg52.h>   
#include"NBCTFT.h"  
#include <math.h>
#define White          0xFFFF   
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0
extern void delayms(unsigned int count);
int re1=320;
void kaiji(void)
{
    uint i;
    float j;
    CLR_Screen(White);
	Show_RGB(0,240,0,148,Blue2);
	for(i=0;i<=10;i++)
	{ delayms(200);
	  LCD_PutString56(140,80-2*i,"��",Red,Blue2);
	 }
	 xian(168,88,28,20,Yellow);
	 CH(120,150,65,10,0x89ab);	  
   for(i=0;i<142;i++)	{
   LCD_PutString(33,290-i,"?",Red,White);
   delayms(10);
   LCD_PutString(33,290-i,"?",White,White);
			   }
	 for(i=0;i<82;i++)	{
   LCD_PutString(33,132-i,"?",Red,Blue2);
   delayms(10);
   LCD_PutString(33,132-i,"?",Blue2,Blue2);
			   }
        for(i =0;i<10;i++){
     	for(j=0;j<7;j++){
	    LCD_PutString(34+(int)(cos((i+15*j)*4*0.01745)*i*2),50+(int)(sin((i+15*j)*4*0.01745)*i*2),"*",Red+4*i,Blue2);
	     LCD_PutString(34+(int)(cos((i+15*j+30)*4*0.01745)*i*3),50+(int)(sin((i+15*j+30)*4*0.01745)*i*3),"*",Red+4*i,Blue2);        
	}	
	 delayms(50);
	}
	 for(i=0;i<=24;i++)
	 {delayms(200);
	 LCD_PutString(i,150,"2015���ѧ��",Black,White);
	 LCD_PutString(144-i,150,"��Ƭ������",Black,White);
	  
	 }
	 for(i=0;i<=40;i++)
	 {
	 Put_Line(115,178+i,120,178+i,Blue);  
	 }	delayms(20);
	 for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(115,178+i,120,178+i,White);  
	 }
	 for(i=85;i>=30;i-=2)
	 { delayms(50);
	 LCD_PutString29(i,195,"������",Blue,White);
	 LCD_PutString(i+32,290,"(023)",Blue,White);
	 }
	 for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(60+i,210,60+i,200,Blue);  
	 }
	  for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(60+i,210,60+i,200,White);  
	 }
	 LCD_PutString29(85,195,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(120,195,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(155,195,"��",Red,White);
	 delayms(500);
	 for(i=0;i<=100;i++)
	 { delayms(20);
	 Put_Line(90+i,230,90+i,245,Blue2);  
	 }
	 delayms(500);
	 for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(80+i,270,80+i,260,Blue);  
	 }
	  for(i=0;i<=40;i++)
	 { delayms(20);
	 Put_Line(80+i,270,80+i,260,White);  
	 }
	 LCD_PutString29(100,255,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(135,255,"��",Red,White);
	 delayms(500);
	 LCD_PutString29(170,255,"��",Red,White);
	 delayms(500);
	 Show_bian(0,0,240,320,10,Green);
}
//////////////////////////////////////////////////////////
//���¶ȱ�
//////////////////////////////////////////////////////////
void biao(void)
{ int i;
 Put_rectange(92,50,148,250,Blue);
 for(i=50;i<=250;i+=4)
 {
  if(i==50||i==50+5*4||i==50+10*4||i==50+15*4||i==50+20*4||i==50+25*4||i==50+30*4||i==50+35*4||i==50+40*4||i==50+45*4||i==50+50*4)
  Put_Line(92,i,82,i,Black);
  else
  Put_Line(92,i,87,i,Black);
 }
 for(i=50;i<=250;i+=4)
 {
 if(i==50)
 LCD_PutString(66,42,"50",Black,White);
 if(i==50+5*4)
 LCD_PutString(66,42+5*4,"45",Black,White);
 if(i==50+10*4)
 LCD_PutString(66,42+10*4,"40",Black,White);
 if(i==50+15*4)
 LCD_PutString(66,42+15*4,"35",Black,White);
 if(i==50+20*4)
 LCD_PutString(66,42+20*4,"30",Black,White);
 if(i==50+25*4)
 LCD_PutString(66,42+25*4,"25",Black,White);
 if(i==50+30*4)
 LCD_PutString(66,42+30*4,"20",Black,White);
 if(i==50+35*4)
 LCD_PutString(66,42+35*4,"15",Black,White);
 if(i==50+40*4)
 LCD_PutString(66,42+40*4,"10",Black,White);
 if(i==50+45*4)
 LCD_PutString(74,42+45*4,"5",Black,White);
 if(i==50+50*4)
 LCD_PutString(74,42+50*4,"0",Black,White);
 }
 LCD_PutString32(20,270,"�¶�       ���϶�",Black,White);
}
/////////////////////////////////////////////////////////////
//���¶�����
////////////////////////////////////////////////////////////
void show(int di,int gao)
{

Show_RGB(93,147,50,50+4*(50-gao),Red);
Show_RGB(93,147,50+4*(50-gao),50+4*(50-di),Green);
Show_RGB(93,147,50+4*(50-di),250,Blue);
}
///////////////////////////////////////////////////////////////////////////////////
//��ָ��
//////////////////////////////////////////////////////////////////////////////////
void zhizhen(int re,int bcolor)
{

if(re!=re1)
{
//LCD_PutChar(93,50+4*(50-re1)-8,'<',bcolor,bcolor);
LCD_PutString32(93,50+4*(50-re1)-16,"��",bcolor,bcolor);
re1=re;
}
//LCD_PutChar(93,50+4*(50-re)-8,'<',White,bcolor);
LCD_PutString32(93,50+4*(50-re1)-16,"��",White,bcolor);
}
//////////////////////////////////////////////////
//������
////////////////////////////////////////////
void zuobiao()
{
 LCD_PutString32(200,264,"��",Black,White);
 LCD_PutString32(14,24,"��",Black,White);
 Put_Line(30,40,30,290,Black);
 Put_Line(30,280,205,280,Black);
 LCD_PutString(214,284,"T",Black,White);
 LCD_PutString(14,24,"C",Black,White);
 LCD_PutString(4,64,"Max",Red,White);

}
