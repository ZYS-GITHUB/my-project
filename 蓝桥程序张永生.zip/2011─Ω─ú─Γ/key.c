#include <reg51.h>
#include "absacc.h"
sbit s4=P3^3;
sbit s5=P3^2;
sbit s6=P3^1;
sbit s7=P3^0;
sbit dianji=P3^4;
#define uchar unsigned char
#define uint unsigned int
bit flag1=0,flag2=0,flag3=0,flag4=0;
uint max=35,min=30,t=0;
extern uint read_temp();
extern void writeep(uchar addr,uchar word);
void delay(int ms)
{
	int i;
while(ms--)
{
for(i=0;i<=50;i++);
}
}
void keyscan()
{
if (s4==0)
{
delay(10);
while(s4==0);
flag1=1;	
}

if (s5==0)
{
delay(10);
while(s5==0);
flag2=1;	
}

if (s6==0)
{
delay(10);
while(s6==0);
flag3=1;	
}

if (s7==0)
{
delay(10);
while(s7==0);
flag4=1;	
}
}
void showre()
{extern uchar duabuf[8];
	uint temp;
temp=read_temp();
t=(uint)temp*0.0625;	
duabuf[6]=t/10%10;
duabuf[7]=t%10;
duabuf[0]=max/10%10;
duabuf[1]=max%10;
duabuf[2]=min/10%10;
duabuf[3]=min%10;
}
void chulikey()
{
extern bit flag;
	keyscan();
if(flag)
{
flag=0;
writeep(0x00,max);	
delay(20);
writeep(0x01,min);
	delay(20);
}
if(flag1)
{
flag1=0;
	max++;
	if(max>=99)max=99;
	if(min>=max)max=min+1;
}
if(flag2)
{
flag2=0;
	min++;
	if(min>=99)min=99;
	if(min>=max)min=max-1;
}
if(flag3)
{
flag3=0;
	max--;
if(max<=0)max=0;
if(max<=min)max=min+1;	
}
if(flag4)
{
flag4=0;
	min--;
if(min<=0)min=0;
if(min>=max)min=max-1;	
}
}
void jidian(bit flag)
{

if(flag==0)
{
XBYTE[0XA000]=0X00;
}
if(flag==1)
{
XBYTE[0XA000]=0X10;
}
}
void xinhao()
{
if(t<min)
{
jidian(1);
	ET1=0;	dianji=1;
}
else if(t>max)
{
ET1=1;jidian(0);
}
else
{
	ET1=0;
	dianji=1;
	jidian(0);
	
}
}