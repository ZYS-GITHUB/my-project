#include <reg51.h>
sbit s7=P3^0;
sbit s6=P3^1;
bit flag6=0;
bit flag7=0;
void delay(uint ms)
{
uint i;
while(ms--)
{for(i=0;i<=50;i++);}
}
void keyscan()
{
if(s7==0)
{
  delay(10);
	while(s7==0);
	flag7=1;
}
if(s6==0)
{
  delay(10);
	while(s6==0);
	flag6=1;
}
}