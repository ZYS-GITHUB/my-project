           /*
XBYTE[0X8000]=0XFE;
XBYTE[0X8000]=0XFF;
XBYTE[0XA000]=0X10;
XBYTE[0XA000]=0X00;
XBYTE[0XE000]=0XFF;
XBYTE[0XC000]=0X01<<dspcom;
XBYTE[0XE000]=tab[duabuf1[dspcom]];
*/
						
						#include <reg52.h>
             #include "onewire.h"
						 #include "absacc.h"
             #define uchar unsigned char
            #define uint unsigned int
             uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
             uchar duabuf[8]={10,10,10,10,10,10,10,10};
             uchar duabuf1[8]={10,10,10,10,10,10,10,10};
             uint TMAX=30;
             uint TMIN=20;
             uchar th,tl,dspcom;
          
            uint wenpinglv=0;
            uint ledji1=0;
            uint ledji2=0;
            uint ledji3=0;
             uint re;
            bit wenflag=0;
            bit deng1=0;
            bit deng2=0;
            bit deng3=0;
            bit deng11=0;
            bit deng22=0;
            bit deng33=0;
            uint jid1=0;
            uint jid2=0;
            uint jid3=0;
            void initt0(uint ms)
            {
          unsigned long tme;
          tme=12000000/12;
          tme=(tme*ms)/1000;
          tme=(65536-tme);
          th=(uchar)(tme>>8);
          tl=(uchar)(tme);
          TMOD&=0xf0;
          TMOD|=0x01;
          TH0=th;
          TL0=tl;
          ET0=1;
          TR0=1;
    }
         
          void display()
          {
   XBYTE[0XE000]=0XFF;
   XBYTE[0XC000]=0X01<<dspcom;
   XBYTE[0XE000]=tab[duabuf[dspcom]];
       if(++dspcom==8)dspcom=0;
     }
        void display1()
        {
   XBYTE[0XE000]=0XFF;
   XBYTE[0XC000]=0X01<<dspcom;
   XBYTE[0XE000]=tab[duabuf1[dspcom]];
       if(++dspcom==8)dspcom=0;
     }
        
          void chuli(uint wen)
          {
       uint wen1;
       wen1=(uint)wen*0.0625;
       if(wen1<=TMAX&&wen1>=TMIN)
      {
        duabuf[1]=1;
      }
       else if(wen1<TMIN)
         {
           duabuf[1]=0;
         }
          else if(wen1>TMAX)
         {
           duabuf[1]=2;
         }
         if(TMIN>=TMAX)
         {
         duabuf[1]=10;
         }
         duabuf[7]=wen1%10;
         duabuf[6]=wen1/10%10;
         duabuf[0]=11;
         duabuf[2]=11;
         
         if(duabuf[1]==0)
         { 
          jid1++;
          jid2=0;
          jid3=0;
        if(jid1<=1)
        {
XBYTE[0XA000]=0X00;
         }
          else if(jid1>1)
          {
           
            if(jid1>100)
            {jid1=5;}
            deng11=1;
						deng22=0;
            deng33=0;
        if(deng1==1)
          {
         
             XBYTE[0X8000]=0XFE;
           }else{ XBYTE[0X8000]=0XFF;}
         }
      }
        
      if(duabuf[1]==1)
       { 
        jid1=0;
        jid2++;
         jid3=0;
        if(jid2<=1)
         {
XBYTE[0XA000]=0X00;
        }
         else if(jid2>1)
        {
            
           if(jid2>100)
           {jid2=5;}
            deng11=0;
						deng22=1;
            deng33=0;
           if(deng2==1)
          {
          
            XBYTE[0X8000]=0XFE;
          }else{ XBYTE[0X8000]=0XFF;}
					
        }
        } 
         
        if(duabuf[1]==2)
       { 
          jid1=0;
          jid2=0;
          jid3++;
         if(jid3<=1)
         {
        XBYTE[0XA000]=0X10;
         }
         if(jid3>1)
        {
            
           if(jid3>100)
            {jid3=5;}
						deng11=0;
						deng22=0;
            deng33=1;
           if(deng3==1)
           {
          
            XBYTE[0X8000]=0XFE;						
           }else{ XBYTE[0X8000]=0XFF;}
         }
       }
       
         if(duabuf[1]==10)
       { 
          jid1=0;
          jid2=0;
          jid3=0;

				 XBYTE[0X8000]=0XFD;
     
         }
       }
          void wenstart()
         {
       
         if(wenflag)
         {
          wenflag=0;
        re=read_temp();
        }
         chuli(re);
      }
        

			
			void int0() interrupt 1
        {
        extern bit setmood;
        TH0=th;
        TL0=tl;
     
        wenpinglv++;
        if(wenpinglv>=100)
         {
           wenpinglv=0;
          wenflag=1;
       }
      if(deng11==1)
       {
         ledji1++;
          if(ledji1>=400)
          {
          ledji1=0;
         deng1=~deng1;
          }
        }
          if(deng22==1)
        {
          ledji2++;
          if(ledji2>=200)
           {
          ledji2=0;
           deng2=~deng2;
        }
        }
          if(deng33==1)
         {
           ledji3++;
          if(ledji3>=100)
           {
          ledji3=0;
          deng3=~deng3;
          }
        }
       if(setmood==0)
       display();
        else
        display1();
       }