#ifndef _ONEWIRE_H
#define _ONEWIRE_H

#include "reg52.h"


#define uchar unsigned char
#define uint unsigned int
//IC���Ŷ���
sbit DQ = P1^4;

//��������
void Delay_OneWire(unsigned int t);
void Write_DS18B20(unsigned char dat);
bit Init_DS18B20(void);
unsigned char Read_DS18B20(void);
uint read_temp();
#endif