#include <reg52.h>
#include "iic.h"
#include "ds1302.h"
#include "absacc.h"
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
uchar duabuf[8]={10,10,10,10,10,10,10,10};
uchar duabuf1[8]={10,10,10,10,10,10,10,10};
uchar th,tl,dspcom;
uint cnt;
bit flag=0;
bit setauto=0;
bit setep=0;
bit beez=0;
bit zong=0;
bit jidian=0;
uchar temp;
char humi=50;
uchar adtemp;
void init_t0(uint ms);
void display();
void display1();
void chuli(uchar ad);
void show1();
extern keyscan();
extern uchar dtime[7][2];
extern void openji(bit jiflag,bit beflag);
//extern void beep(bit beflag);
extern void ledlight(bit ledflag);
extern void show1set();
extern void show2();
extern void delay(void);
extern uint readeep(uchar device,uchar add);

void main()
{ 
  extern  bit flag1;
	extern  bit flag2;
	extern  bit flag3;
	extern  bit flag4;
	EA=1;
	init_t0(1);
	init1302();
	humi=readeep(0xa0,0x00);
 while(1)
 {
	 keyscan();
	 if(flag1==1)
	 {
	 flag1=0;setauto=~setauto;
	 }
	 while(setauto==0)
	 {	
	 keyscan();
	 if(flag1==1)
	 {
	 flag1=0;setauto=~setauto;
	 }		 
	 if(flag2==1)
	{
	flag2=0;
	setep=~setep;
	}
	if(setep==0)
	{ show1();}
  else if(setep==1)
	{ show1set();}
	 }
	while(setauto==1)
	 { 	 
		 keyscan();
	 if(flag1==1)
	 {
	 flag1=0;setauto=~setauto;
	 }
	 	 if(flag3==1)
	 {jidian=1;
	   flag3=0;
	 	
	 }
	 	 	 if(flag4==1)
	 {	jidian=0;
	    flag4=0;
		 
	 }
	 openji(jidian,beez);
	 	 if(flag2==1)
	 {
	 flag2=0;beez=~beez;
	 }
	 if(zong==1){zong=0;beez=1;}
//	 	beep(beez);
	  openji(jidian,beez);
	
		 setep=0;
	if(flag)
	{flag=0;
   temp=readad(3);
	}
	adtemp=(uchar)(temp*0.39);
		chuli(adtemp);
	show2();
	 }
	 
 }
}
void show1()
{
  get1302();
	ledlight(1);
	openji(jidian,0);
//	beep(0);
	if(flag)
	{flag=0;
   temp=readad(3);
	}
	adtemp=(uchar)(temp*0.39);
	if(adtemp<=humi)
	{
		openji(1,0);
		zong=1;
	}
	else
	{
	  openji(0,0);
		zong=0;
	}
	chuli(adtemp);
}
void chuli(uchar ad)
{
  duabuf[0]=dtime[2][0];
	duabuf[1]=dtime[2][1];
	duabuf[2]=11;
	duabuf[3]=dtime[1][0];
	duabuf[4]=dtime[1][1];
  duabuf[6]=ad/10%10;
  duabuf[7]=ad%10;	
}
void init_t0(uint ms)
{
  unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=(65536-tme);
	tme=tme+12;
	th=(uchar)(tme>>8);
	tl=(uchar)(tme);
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
  cnt++;
	if(cnt>=100)
	{
	  cnt=0;
		flag=1;
	}
	if(setep==0)
	{display();}
	else if(setep==1)
	{display1();}
}
void display()
{
	XBYTE[0XE000] = 0XFF;
	XBYTE[0Xc000] = 0x01<<dspcom;
	XBYTE[0XE000] = tab[duabuf[dspcom]];
//  P2=(P2&0x1f)|0xc0;
//	P0=0x01<<dspcom;
//	P2=(P2&0x1f)|0xe0;
//	P0=tab[duabuf[dspcom]];
	if(++dspcom==8)dspcom=0;	
}
void display1()
{
	XBYTE[0XE000] = 0XFF;
	XBYTE[0Xc000] = 0x01<<dspcom;
	XBYTE[0XE000] = tab[duabuf1[dspcom]];
	if(++dspcom==8)dspcom=0;	
}
	