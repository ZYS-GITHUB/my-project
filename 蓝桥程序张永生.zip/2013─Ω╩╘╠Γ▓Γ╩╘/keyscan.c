#include <reg52.h>
#include "absacc.h"
#define uchar unsigned char
#define uint unsigned int
	extern uchar duabuf1[8];
	extern void writeeep(uchar device,uchar add,uchar word);
sbit k1=P3^0;
sbit k2=P3^1;
sbit k3=P3^2;
sbit k4=P3^3;
bit flag1=0;
bit flag2=0;
bit flag3=0;
bit flag4=0;
uchar temp12;
//void keyscan()
//{
//if(k1==0)
//{
//while(k1==0);
//	flag1=1;
//}
//if(k2==0)
//{
//while(k2==0);
//	flag2=1;
//}
//if(k3==0)
//{
//	
//while(k3==0);
//	flag3=1;
//}
//if(k4==0)
//{
//	
//while(k4==0);
//	flag4=1;
//}
//}
void keyscan()
{
  uchar temp;
	P3=0xfe;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xee: temp12=0;break;
				case 0xde: temp12=0;break;
				case 0xbe: temp12=0;break;
				case 0x7e: flag1=1;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xfd;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xed: temp12=0;break;
				case 0xdd: temp12=0;break;
				case 0xbd: temp12=0;break;
				case 0x7d: flag2=1;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xfb;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xeb: temp12=0;break;
				case 0xdb: temp12=0;break;
				case 0xbb: temp12=0;break;
				case 0x7b: flag3=1;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xf7;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xe7: temp12=0;break;
				case 0xd7: temp12=0;break;
				case 0xb7: temp12=0;break;
				case 0x77: flag4=1;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
}


	void openji(bit jiflag,bit beflag)
	{
	uchar temp = 0x00;
	if(jiflag==1)
	{
   temp|=(0x01<<4);
	}
  if(jiflag==0)
	{
   temp &=(~(0x01<<4));	
	}	
	
	if(beflag==1)
	{
   temp |= (0x01<<6);	
	}
	if(beflag==0)
	{
   temp &=(~(0x01<<6));
	}
		XBYTE[0XA000] = temp;
	}
//	void beep(bit beflag)
//	{
//		uchar temp=0x00;
//	if(beflag==1)
//	{
//   temp =P0| (0x01<<6);	
//	}
//	if(beflag==0)
//	{
//   temp =P0&(~(0x01<<6));
//	}
//	XBYTE[0XA000] = temp;
//	}
	void ledlight(bit ledflag)
	{
	if(ledflag==1)
	{
		XBYTE[0X8000]=0xfe;
//	P2=(P2&0x1f)|0x80;
//	P0=(P0&0x00)|0xfe;	
	}
  if(ledflag==0)
	{
		XBYTE[0X8000]=0xfd;
//	P2=(P2&0x1f)|0x80;
//	P0=(P0&0x00)|0xfd;
	}	
	}
	void show1set()
	{
extern char humi;
if(flag3==1)
{flag3=0;humi++;}
if(flag4==1)
{flag4=0;humi--;}
if(humi>99)humi=99;
if(humi<0)humi=0;
duabuf1[7]=humi%10;
duabuf1[6]=humi/10%10;
duabuf1[1]=11;
duabuf1[0]=11;  
writeeep(0xa0,0x00,humi);

	}
	void show2()
	{
		XBYTE[0X8000]=0xfd;
//	P2=(P2&0x1f)|0x80;
//	P0=(P0&0x00)|0xf7;
	}