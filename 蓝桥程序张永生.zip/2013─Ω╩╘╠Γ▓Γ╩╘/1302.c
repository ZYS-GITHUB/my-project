#include <reg52.h>
#include "ds1302.h"
#define uchar unsigned char
#define uint unsigned int
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
uchar duabuf[8]={0,0,0,0,0,0,0,0};
void init_t0(uint ms);
void display();
uchar th,tl,dspcom;
uint cnt;
bit flag=0;

void main()
{extern uchar dtime[7][2];
	EA=1;
	init_t0(1);
	init1302();
while(1)
{
 
	if(flag)
	{ get1302();flag=0;
  duabuf[0]=dtime[2][0];
	duabuf[1]=dtime[2][1];
	duabuf[2]=11;
	duabuf[3]=dtime[1][0];
	duabuf[4]=dtime[1][1];
	duabuf[5]=11;
	duabuf[6]=dtime[0][0];
	duabuf[7]=dtime[0][1];}
}
}
void init_t0(uint ms)
{
  unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=65536-tme;
	tme=tme+12;
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0()interrupt 1
{
	TH0=th;
	TL0=tl;
	cnt++;
	if(cnt>=100)
	{
	 cnt=0;
	 flag=1;
	}
	display();
}
void display()
{
  P2=(P2&0x1f)|0xc0;
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xe0;
	P0=tab[duabuf[dspcom]];
	if(++dspcom==8)dspcom=0;
	
}