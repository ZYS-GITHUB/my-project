#include "stm32f10x.h"
#include "allconfig.h"

u8 chh,chl;
int main(void)
{
    Adc_Init();
    USART_Config();	
    while(1){
    sendch[2]=ADCvalue[0]%256;
		sendch[3]=ADCvalue[0]/256;	
    }          
}






/******************************************END OF FILE*************************/
