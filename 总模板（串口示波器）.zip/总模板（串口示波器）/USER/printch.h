#ifndef _PRINTCH_H_
#define _PRINTCH_H_
#include "stm32f10x.h"
#include <stdio.h>
//���ô���
void USART_Configuration()
{
   
  GPIO_InitTypeDef GPIO_InitStructure;
  USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//��λ��ռ���ȼ� ��λ��Ӧ���ȼ�
  NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority =3;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
  //�������� PA3 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//��������
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  //��������PA2
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;//�������
  GPIO_Init(GPIOA, &GPIO_InitStructure);
   /* USART_InitStruct members default value */
  USART_InitStruct.USART_BaudRate = 9600;
  USART_InitStruct.USART_WordLength = USART_WordLength_8b;
  USART_InitStruct.USART_StopBits = USART_StopBits_1;
  USART_InitStruct.USART_Parity = USART_Parity_No;
  USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;  
  //�ȳ�ʼ�����
  USART_Init(USART1,&USART_InitStruct);//��ʼ��
  USART_Cmd(USART1,ENABLE);
  //�򿪽����ж�
  USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);	
}
void USART_SendString(int8_t *str)
{
    uint8_t index = 0;
    
    do
    {
        USART_SendData(USART1,str[index]);
        while(USART_GetFlagStatus(USART1,USART_FLAG_TXE) == RESET);
        index++;  
    }
    while(str[index] != 0);  
    
}
int fputc(int ch, FILE*f)
{
    USART_SendData(USART1, (uint8_t)ch);
	//���ϲ�ѯ �����ֽ���ɱ�־ ���ͳ�ȥ����λ
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	
	return ch;	
}
#endif
