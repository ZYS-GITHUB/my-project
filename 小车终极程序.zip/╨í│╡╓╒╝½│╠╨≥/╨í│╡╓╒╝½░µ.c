  #include <reg52.h>
 sbit ft=P3^7;
sbit pl=P3^6;
sbit pe=P3^5;
sbit re=P3^4;
 sbit k1=P3^2;
 sbit k3=P2^6;
 sbit k2=P2^7;
 sbit ena=P2^0;
 sbit in1=P2^1;
 sbit in2=P2^2;
 sbit in3=P2^3;
 sbit in4=P2^4;
 sbit enb=P2^5;
 sbit r2=P1^0;
 sbit r1=P1^1;
 sbit r0=P1^2;
 sbit zuo=P1^6;
 sbit you=P1^7;
  unsigned char code duan[18] = {	
0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,
0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};
//0��1��2��3��4��5��6��7��8��9��A��b��C��d��E��F����ʾ��
unsigned char code duan1[10] = {0xbf,0x86,0xdb,0xcf,0xe6,0xed,0xfd,0x87,0xff,0xef} ;
    unsigned char   xian[10];
	unsigned char   xian1[10];
    unsigned char   i=0;
	 unsigned char   d=0;
    unsigned int    cnt=0;
	unsigned int    z=0;
	unsigned int    y=0;
 static   unsigned long	  sec=0;
 static   unsigned long	  lol=0;
    unsigned int    ajs=0;
	unsigned long   round=0;
    unsigned long   cycle=0;
 	unsigned int	  t=0;
    unsigned int	  m=0;
	unsigned int	  n=0;
	void wending();
	void delay(unsigned int z);
    int delayus();
 void main()
{
  IE=0x87;	/*�ⲿINT0/1�жϼ��ܿ���*/
  TCON=0x05;/*�ⲿ�ж�������*/
  P0=0x00;	/*����ܿ�ʼȫ��*/
  TMOD=0x01;
  TH0=0xfc;
  TL0=0x1b;
  while(1)
  {
   


 /*******����ܿ���*******/

     if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	   xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
	
	   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
		
		
	   }
	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		 
		 }
		  else
		  {
		  sec=0;
		 }
		} 
		 }  /*if(cnt>=1000)*/
        
         
/*********************�������*******************************/		 
		 
	switch(ajs)
	{
	  case 1: in1=0;in2=1;in3=1;in4=0;pe=1;
	   while(ajs==1)
	           { 		   
			   while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
   shuma(cnt) 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
    shuma (cnt)
    shuma (cnt)			     
    delay(1);
    ena=0;enb=0;
    delay(3);
    enb=1;ena=1;};   break;
    case 2: in1=0;in2=1;in3=1;in4=0;pe=0;
    while(ajs==2)
    { while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
   shuma (cnt)
		 }
   } 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
   shuma (cnt)
   } 

		if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	  xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
			   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
	
			   }	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		  
		  }
		  else
		  {
		 sec=0;
		 }
		} 
		  }
			    
	            delay(1);
	            ena=0;enb=0;
	            delay(5);
				enb=1;ena=1;};                          break;
	  case 3:	in1=0;in2=1;in3=1;in4=0; 
	  while(ajs==3)
	           { while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
    shuma (cnt)
   } 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
    shuma (cnt)
   } 

		if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	    xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
			   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
	
			   }	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		  
		  }
		  else
		  {
		 sec=0;
		 }
		} 
		  }
			    
	            delay(1);
	            ena=0;enb=0;
	            delay(3);
				enb=1;ena=1;};   break;
	  case 4:	in1=0;in2=1;in3=1;in4=0;
			  while(ajs==4)
	           { while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
    shuma (cnt)
   } 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
    shuma (cnt)
   } 

			   if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	   xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
	
				}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
		   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
	
		
	   }
	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		 
		  }
		  else
		  {
		  sec=0;
		 }
		} 
		 }
			   
	            delay(10);
	            ena=0;enb=0;
	            delay(1);
				enb=1;ena=1;}  ;                        break;
	  case 5:	in1=0;in2=1;in3=1;in4=0;
	   while(ajs==5)
	           { while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
    shuma (cnt)
   } 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
    shuma (cnt)
   } 

		if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	  xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
			   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
	
			   }	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		  
		  }
		  else
		  {
		 sec=0;
		 }
		} 
		  }
			    
	            delay(1);
	            ena=0;enb=0;
	            delay(3);
				enb=1;ena=1;};   break;
	  case 6:	ena=0;enb=0;
				n=delayus();
				if(n==6)
				{ while(1)
				{
				 in1=0;in2=1;enb=0;in3=0;in4=1;
				 delay(1);
				 ena=1;
				 delay(1);
				 ena=0;
				  for(z=0;z<=1000;z++); 
				  break;
				  }  
				};
				n=delayus();
				if(n>=8)
				{
				 in1=0;in2=1;in3=1;in4=0;
				ena=1;enb=1;
				 delay(5);
				};                break;
	 case 7: in1=0;in2=1;in3=1;in4=0; 
	            while(ajs==7)
	           { while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
    shuma (cnt)
   } 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
    if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
	
	   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
		
		
	   }
	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		 
		 }
		  else
		  {
		  sec=0;
		 }
		} 
		 }
   } 

		if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	  xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
			   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
	
			   }	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		  
		  }
		  else
		  {
		 sec=0;
		 }
		} 
		  }
			    
	            delay(1);
	            ena=0;enb=0;
	            delay(3);
				enb=1;ena=1;};   break;
	 case 8: in1=0;in2=1;in3=1;in4=0;
	 while(ajs==8)
	           { while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
    if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
	
	   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
		
		
	   }
	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		 
		 }
		  else
		  {
		  sec=0;
		 }
		} 
		 }
   } 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
    shuma (cnt)
   } 

		if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	  xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
			   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
	
			   }	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		  
		  }
		  else
		  {
		 sec=0;
		 }
		} 
		  }
			    
	            delay(10);
	            ena=0;enb=0;
	            delay(1);
				enb=1;ena=1;};   break;
	 case 9: in1=0;in2=1;in3=1;in4=0;
	 while(ajs==9)
	           { while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
    shuma(cnt)
   } 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
    if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
	
	   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
		
		
	   }
	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		 
		 }
		  else
		  {
		  sec=0;
		 }
		} 
		 }
   } 

		if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	  xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
			   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
	
			   }	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		  
		  }
		  else
		  {
		 sec=0;
		 }
		} 
		  }
			    
	            delay(1);
	            ena=0;enb=0;
	            delay(3);
				enb=1;ena=1;};   break;
	 case 10: in1=0;in2=1;in3=1;in4=0;
				  while(ajs==10)
	           { while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
    shuma (cnt)
   } 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
   shuma (cnt)
   } 

		shuma (cnt)
		  }
			    
	            delay(1);
	            ena=0;enb=0;
	            delay(5);
				enb=1;ena=1;};   break;
	case 11:in1=0;in2=1;in3=1;in4=0;
	while(ajs==11)
	           { while(zuo==1&&you==0)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=1;enb=0;
   delay(1);
   ena=0;enb=1;
    shuma (cnt)
   } 
   while(zuo==0&&you==1)
   {
   in1=0;in2=1;in3=1;in4=0;
   delay(8);
   ena=0;enb=1;
   delay(1);
   ena=1;enb=0;
    shuma (cnt)
   } 

		if(cnt>=1000)
	  {
	   cnt=0;
	   sec++;
	  xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
	   if(sec<=10)
	   { if(sec<=9)
	   {
	    xian[0]=duan[sec%10];
	   	xian[1]=0x00;
		xian[2]=0x00;
		
		
		}
	   
	   else 
	   {
	   	xian[0]=duan[sec%10];
		xian[1]=duan[1];
		xian[2]=0x00;
	
			   } }
	   else if(sec<=100)
	   {  if(sec<=99)
	   { xian[1]=duan[sec/10%10];
	   	 xian[0]=duan[sec%10];
		 xian[2]=0x00;
		 
		}
	   
	   else 
	   {xian[0]=duan[0];
	   	xian[1]=duan[0];
		xian[2]=duan[1];
	
			   }	   }
		else if(sec<=1000)
		{ if(sec<=999)
		{ xian[2]=duan[sec/100%10];
		  xian[1]=duan[sec/10%10];
	   	  xian[0]=duan[sec%10];
		  
		  }
		  else
		  {
		 sec=0;
		 }
		} 
		  }
			    
	            delay(1);
	            ena=0;enb=0;
	            delay(3);
				enb=1;ena=1;};   break;
	case 12:ena=0;enb=0;while(1);break;
		     default: ena=0;enb=0;
	            
	          }
	 
	     }	/*while(1)*/
		 }	/*main*/

 void int0(void) interrupt 0
 { for(m=0;m<=10000;m++);    
       ajs++;
       TR0=1;
	  
    
	  
 	   }

  void 	tf0(void) interrupt 1
   {TH0=0xfc;
    TL0=0x1b;
	cnt++;
	cycle++;
/*P0	= 0x00;
P1 = ~((P1&0xF8) | i);

P0 = xian[i];

if (i < 6)
i=i+1;
else
i =0; */

   	switch (i)
	  {
	   case 0: P0=xian[0]; r0=1;r1=1;r2=1; i++; break;
	   case 1: P0=xian[1]; r0=0;r1=1;r2=1; i++; break;
	   case 2: P0=xian[2]; r0=1;r1=0;r2=1; i++; break;
	   case 3: P0=0x00;    r0=0;r1=0;r2=1; i=0; break;
	    
	   	}
	   	switch(d)	  	
	  { case 0: P0=xian[4]; r0=1;r1=1;r2=0; d++; break;
	   case 1: P0=xian[5]; r0=0;r1=1;r2=0; d++; break;
	   case 2: P0=xian[6]; r0=1;r1=0;r2=0; d++; break;
	   case 3: P0=xian[7]; r0=0;r1=0;r2=0; d=0; break;	   
	  }   
   }
  
  void int1(void) interrupt 2
  {
  	round++;
	lol=2042*round;
		xian[4]=duan[lol/100%10];
		xian[5]=duan[lol/1000%10];
		xian[6]=duan1[lol/10000%10];
		xian[7]=duan[lol/100000%10];
  }
  
   
 void wending()
 { int i;
   for(i=0;i<=20000;i++);
 }
 void delay(unsigned int z)
  {
   unsigned int x,y;
   for(x=z;x>0;x--)
   for(y=1000;y>0;y--);
  }
  int delayus()
  {
   if(ajs==6)
  {if(cycle>=1000)
   	 { cycle=0;
	   t++;
	 }
	 return(t);
   	 }
  }				 