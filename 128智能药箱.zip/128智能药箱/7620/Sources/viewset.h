void signalcha()
  {
   LCD_PutChar16(188,10,'T',Black,White);
   Show_RGB(204,208,32,34,Red);
   Show_RGB(212,216,26,34,White);
   Show_RGB(220,224,20,34,White);
   Show_RGB(228,232,14,34,White);
  }
void signalman()
  {
   LCD_PutChar16(188,10,'T',Black,White);
   Show_RGB(204,208,32,34,Green);
   Show_RGB(212,216,26,34,Green);
   Show_RGB(220,224,20,34,Green);
   Show_RGB(228,232,14,34,Green); 
  }
void shujuon(uchar sw)
  {
    if(sw)LCD_PutChar16(188,10,'T',Green,White);
    else LCD_PutChar16(188,10,'T',Black,White);
  }
void chaozhi(uchar sw)
  {
   if(sw)
    {
      LCD_PutChar16(112,296,'T',Red,Red); 
      LCD_PutChar16(112,272,'T',Red,Red);
      LCD_PutChar16(112,248,'T',Red,Red);
      LCD_PutChar16(112,224,'T',Red,Red);
    }
  else
    {
      LCD_PutChar16(112,296,'T',White,White); 
      LCD_PutChar16(112,272,'T',White,White);
      LCD_PutChar16(112,248,'T',White,White);
      LCD_PutChar16(112,224,'T',White,White); 
    }
  }
void jinbaomie()
  {
  Put24x24(140,12,"��",Red,White);  
  }
void jinbaoliang()
  {
  Put24x24(140,12,"��",Red,White);  
  }
void zhengdm()
  {
   Put24x24(98,12,"��",Blue,White); 
  }
void zhengdl()
  {
   Put24x24(98,12,"��",Blue,White); 
  }
void connectoff()
  {
  Put24x24(50,12,"��",Green,White);  
  }
void connecton()
  {
  Put24x24(50,12,"��",Green,White);  
  }
void signal(uchar sw)
  {
   if(sw)signalman();
   else signalcha(); 
  }
void emergence(uchar sw)
  {
  if(sw)jinbaoliang();
  else jinbaomie();  
  }
void zhengd(uchar sw)
  {
   if(sw)zhengdl();
   else zhengdm(); 
  }
void connect(uchar sw)
  {
   if(sw)connecton();
   else connectoff(); 
  }
void yaoxiang()
  {
    Show_bian(5,50,141,79,2,Cyan);
    Show_bian(5,80,141,109,2,Blue2);
    Show_bian(5,110,141,139,2,Green);
    Show_bian(5,140,141,169,2,Magenta);
    Show_bian(143,50,240,169,15,Red);
    Show_bian(10,205,110,319,5,Blue2);
    Show_bian(130,205,230,319,5,Blue2);
    LCD_PutString24(8,53,"ҩ��1",Magenta,White);
    LCD_PutString24(8,83,"ҩ��2",Magenta,White);
    LCD_PutString24(8,113,"ҩ��3",Magenta,White);
    LCD_PutString24(8,143,"ҩ��4",Magenta,White);
    LCD_PutString24(36,211,"�¶�",Black,White);
    LCD_PutString24(156,211,"ʪ��",Black,White);
  }
void xiangmode1(uchar mode)
  {
    if(mode==0)
      {
    Put24x24(75,53,"��",Green,White);    
      }
    else if(mode==1)
      {
    Put24x24(75,53,"��",Green,White);   
      }
    else
      {
    Put24x24(75,53,"��",Blue,White);    
      }
  }
void xiangmode2(uchar mode)
  {
    if(mode==0)
      {
    Put24x24(75,83,"��",Green,White);    
      }
    else if(mode==1)
      {
    Put24x24(75,83,"��",Green,White);   
      }
    else
      {
    Put24x24(75,83,"��",Blue,White);    
      }
  }
void xiangmode3(uchar mode)
  {
    if(mode==0)
      {
    Put24x24(75,113,"��",Green,White);    
      }
    else if(mode==1)
      {
    Put24x24(75,113,"��",Green,White);   
      }
    else
      {
    Put24x24(75,113,"��",Blue,White);    
      }
  }
void xiangmode4(uchar mode)
  {
    if(mode==0)
      {
    Put24x24(75,143,"��",Green,White);    
      }
    else if(mode==1)
      {
    Put24x24(75,143,"��",Green,White);   
      }
    else
      {
    Put24x24(75,143,"��",Blue,White);    
      }
  }
void xiangnum1(uint num,uchar type)
  {
    uchar ge,shi,bai;
    ge=num%10+0x30;
    shi=num/10%10+0x30;
    bai=num/100%100+0x30;
    LCD_PutChar(100,57,bai,Red,White);
    LCD_PutChar(108,57,shi,Red,White);
    LCD_PutChar(116,57,ge,Red,White);
    if(type)
      {
       LCD_PutString(124,53,"ke",Blue,White); 
      }
     else
      {
       LCD_PutString(124,53,"ml",Blue,White);  
      }
  }
void xiangnum2(uint num,uchar type)
  {
    uchar ge,shi,bai;
    ge=num%10+0x30;
    shi=num/10%10+0x30;
    bai=num/100%100+0x30;
    LCD_PutChar(100,87,bai,Red,White);
    LCD_PutChar(108,87,shi,Red,White);
    LCD_PutChar(116,87,ge,Red,White);
    if(type)
      {
       LCD_PutString(124,83,"ke",Blue,White); 
      }
     else
      {
       LCD_PutString(124,83,"ml",Blue,White);  
      }
  }
void xiangnum3(uint num,uchar type)
  {
    uchar ge,shi,bai;
    ge=num%10+0x30;
    shi=num/10%10+0x30;
    bai=num/100%100+0x30;
    LCD_PutChar(100,117,bai,Red,White);
    LCD_PutChar(108,117,shi,Red,White);
    LCD_PutChar(116,117,ge,Red,White);
    if(type)
      {
       LCD_PutString(124,113,"ke",Blue,White); 
      }
     else
      {
       LCD_PutString(124,113,"ml",Blue,White);  
      }
  }
void xiangnum4(uint num,uchar type)
  {
    uchar ge,shi,bai;
    ge=num%10+0x30;
    shi=num/10%10+0x30;
    bai=num/100%100+0x30;
    LCD_PutChar(100,147,bai,Red,White);
    LCD_PutChar(108,147,shi,Red,White);
    LCD_PutChar(116,147,ge,Red,White);
    if(type)
      {
       LCD_PutString(124,143,"ke",Blue,White); 
      }
     else
      {
       LCD_PutString(124,143,"ml",Blue,White);  
      }
  }
void setmodeview(uchar mode)
  {
  if(mode==0)
    {
     LCD_PutString24(168,80,"����",Green,White);
     LCD_PutString24(168,108,"ģʽ",Green,White);  
    }
  else if(mode==1)
    {
     LCD_PutString24(168,80,"��ʱ",Blue,White);
     LCD_PutString24(168,108,"ģʽ",Blue,White);      
    }
  else if(mode==2)
    {
     LCD_PutString24(168,80,"����",Cyan,White);
     LCD_PutString24(168,108,"ģʽ",Cyan,White);  
    }
  else if(mode==3)
    {
     LCD_PutString24(168,80,"��ҩ",Blue2,White);
     LCD_PutString24(168,108,"ģʽ",Blue2,White);  
    }
  else
    {
     LCD_PutString24(168,80,"��ҩ",Red,White);
     LCD_PutString24(168,108,"ģʽ",Red,White);  
    }
  }
void clockview(uchar x,uchar y,uchar shis,uchar shig,uchar fens,uchar feng,uchar miaos,uchar miaog,uint color)
  {
    LCD_PutChar16(x,y,shis,color,White);
    LCD_PutChar16(x+16,y,shig,color,White);
    LCD_PutChar16(x+16*2,y,':',color,White);
    LCD_PutChar16(x+16*3,y,fens,color,White);
    LCD_PutChar16(x+16*4,y,feng,color,White);
    LCD_PutChar16(x+16*5,y,':',color,White);
    LCD_PutChar16(x+16*6,y,miaos,color,White);
    LCD_PutChar16(x+16*7,y,miaog,color,White);
  }
void wenshow(uint wen,uint wen1)
  {
  uchar ge,shi,ge1,shi1;
  ge=wen%10+0x30;
  shi=wen/10%10+0x30;
  ge1=wen1%10+0x30;
  shi1=wen1/10%10+0x30;
  LCD_PutChar16(36,250,shi,Blue2,White);
  LCD_PutChar16(52,250,ge,Blue2,White); 
  LCD_PutChar16(68,250,'C',Blue2,White);
  LCD_PutChar16(36,290,shi1,Blue,White);
  LCD_PutChar16(52,290,ge1,Blue,White); 
  LCD_PutChar16(68,290,'C',Blue,White);  
  }
void shishow(uint wen,uint wen1)
  {
  uchar ge,shi,ge1,shi1;
  ge=wen%10+0x30;
  shi=wen/10%10+0x30;
  ge1=wen1%10+0x30;
  shi1=wen1/10%10+0x30;
  LCD_PutChar16(156,250,shi,Blue2,White);
  LCD_PutChar16(172,250,ge,Blue2,White); 
  LCD_PutChar16(188,250,'%',Blue2,White);
  LCD_PutChar16(156,290,shi1,Blue,White);
  LCD_PutChar16(172,290,ge1,Blue,White); 
  LCD_PutChar16(188,290,'%',Blue,White);  
  }
void mainshow()
  {
    signal(0);
    emergence(0);
    zhengd(0);
    connect(0);
    yaoxiang();
    xiangmode1(0);
    xiangmode2(0);
    xiangmode3(0);
    xiangmode4(0);
    xiangnum1(0,0);
    xiangnum2(0,1);
    xiangnum3(0,0);
    xiangnum4(0,1);
    setmodeview(0);
    wenshow(30,28);
    shishow(20,25); 
  }