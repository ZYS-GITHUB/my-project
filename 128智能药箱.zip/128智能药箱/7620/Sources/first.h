extern void delay_1ms(uint n);
uchar menf1=0,menf2=0,menf3=0,menf4=0;
uchar k0=0,k1=0,k2=0,k3=0,k4=0;
void PLL_Init(void)
{
  CLKSEL=0x00; 
  SYNR=0XC0 | 0X09;
  REFDV=0X80 | 0X01;
  PLLCTL_PLLON=1;
  POSTDIV=0X00;
  asm(nop);
  asm(nop);
  while(0==CRGFLG_LOCK); //���໷����
  CLKSEL_PLLSEL=1; //ѡ��PLLʱ��
}
void SCI1_Init()
{
SCI1BDL = (byte)((80000000 /* OSC freq /2*/) / 115200 /* baud rate */ / 16 /*factor*/);
SCI1CR1 = 0X00;                                      /*normal,no parity*/
SCI1CR2 = 0X2C;                                      /*RIE=1,TE=1,RE=1, */
}
void SCI1_putchar(uchar ch)//�����ַ�
{
while(!(SCI1SR1&0X40));//
SCI1DRL=ch;
}
void Put_string1(char *ch)//�����ַ���
{
unsigned char ptr=0;
while(ch[ptr]!=0x7e)
{
SCI1_putchar((uchar)ch[ptr++]);
}
//�����жϷ�����
}
void SCI0_Init()
{
SCI0BDL = (byte)((80000000 /* OSC freq /2*/) / 115200 /* baud rate */ / 16 /*factor*/);
SCI0CR1 = 0X00;                                      /*normal,no parity*/
SCI0CR2 = 0X2C;                                      /*RIE=1,TE=1,RE=1, */
}
void SCI0_putchar(uchar ch)//�����ַ�
{
while(!(SCI0SR1&0X40));
SCI0DRL=ch;
}
void Put_string(char *ch)//�����ַ���
{
unsigned char ptr=0;
while(ch[ptr]!='\0')
{
SCI0_putchar((uchar)ch[ptr++]);
}
//�����жϷ�����
}
void menflag()
  {
    if(PTJ_PTJ0==0) menf1=1;
               else menf1=0;
    if(PTJ_PTJ1==0) menf2=1;
               else menf2=0;
    if(PTJ_PTJ6==0) menf3=1;
               else menf3=0;
    if(PTJ_PTJ7==0) menf4=1;
               else menf4=0;
  }
void keyscan()
  {
    if(PORTK_PK0==0)
      {
        while(PORTK_PK0==0);
        k0=1;
        k1=0;
        k2=0;
        k3=0;
        k4=0;
      }
    if(PORTK_PK1==0)
      {
        while(PORTK_PK1==0);
        k0=0;
        k1=1;
        k2=0;
        k3=0;
        k4=0;
      }
    if(PORTK_PK2==0)
      {
        while(PORTK_PK2==0);
        k0=0;
        k1=0;
        k2=1;
        k3=0;
        k4=0;
      }
    if(PORTK_PK3==0)
      {
        while(PORTK_PK3==0);
        k0=0;
        k1=0;
        k2=0;
        k3=1;
        k4=0;
      }
    if(PORTK_PK4==0)
      {
        while(PORTK_PK4==0);
        k0=0;
        k1=0;
        k2=0;
        k3=0;
        k4=1;
      }
  }
void duanxin(uchar mode)
  {
    if(mode==0)
      {
       PORTB_PB5=1;
       PORTB_PB6=1; 
      }
    else if(mode==1)
      {
       PORTB_PB5=0;
       PORTB_PB6=0;  //����
      }
    else
      {
       PORTB_PB5=0;
       PORTB_PB6=1; //SOS 
      }
  }

void wenshicai()
  {
   t=getDHT11();
   t1=getDHT12();
   temp=t/100;
   hum=t%100;
   temp1=t1/100;
   hum1=t1%100;
  }

