
#include <hidef.h>       
#include "derivative.h"    
#include <MC9S12XS128.h>
#include <math.h>
#include <string.h>
#include "NBCTFT.h"
#define baoyan 1500
#define White          0xFFFF   
#define Black          0x0000
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0
extern unsigned int Device_code;
uchar mainmode=0;
extern uchar dtime[3][2]; 
 uchar ntx[12][28];
 uchar jie[20];
 uchar zh[4][19];
 uchar yuzhi[47];
uchar ctime[12][3][2];
uchar naof[12]={0};
uchar naok[12]={0};
uint yaol[4]={0};
uchar ytype[4]={0};
uchar zf=0,shishi=0;
extern void GetDS1302(void);
extern void InitDS1302(void);
uint t=2020,temp=20,hum=20,t1=2020,temp1=20,hum1=20;
uint tempdi=1,tempgao=35,humdi=1,humgao=40;
extern  unsigned int getDHT11(void);
extern  unsigned int getDHT12(void);
unsigned char ch=0,ch1=0,ch2=0,ch3=0,flag=0;
uchar rx[32],rx1[32],rx2[32],rx3[32],rx4[40]={0};
uchar rxcnt=0,rxcnt1=0,rxcnt2=0,rxcnt3=0,txcnt=0;
uchar *text=rx4;
uchar chuan=0,chuan1=0;
uchar kmen1=0,kmen2=0,kmen3=0,kmen4=0;
uchar baoshi=0;
uchar box=0;
extern struct S_TIME
	{
		uchar SEC;			//00~59
		uchar MIN;			//00~59
		uchar HR;			//00-23
	}TIME;//��ʼ��ʱ�����
#include "first.h"
#include "wifi.h"
#include "viewset.h"
#include "yuyin.h"
#include "modeset.h"

void main(void)
{
  DisableInterrupts;
  DDRH=0XFF;
  DDRE=0XFC;
  DDRK=0X00;
  DDRB=0XFF;
  DDRA=0XFF;
  PORTB=0XFF;
  PORTA=0XFF;
  DDRJ=0X00;
  memset(ctime,'0',sizeof(ctime));
  Device_code=0x9328; 
  PLL_Init();
  SCI0_Init(); 
  SCI1_Init();
  EnableInterrupts; 
  TFT_Initial(); 
  CLR_Screen(White); 
  mainshow();                  
  for(;;)
  {
  if(mainmode==0)
    {
      InitDS1302();
      while(mainmode==0)
        {
         modeset0();
         fangyao();
        }
    }
 if(mainmode==1)
  {
    //InitDS1302();
    setmodeview(0);
    shujuon(0);
    duanxin(0);
    while(mainmode==1)
      {
         GetDS1302();
         wenshicai();
         clockview(55,180,dtime[2][0],dtime[2][1],dtime[1][0],dtime[1][1],dtime[0][0],dtime[0][1],Magenta);
         wenshow(temp,temp1);
         shishow(hum,hum1);
         tempcompare(); 
         xiangmode1(naof[0]||naof[1]||naof[2]);
         xiangmode2(naof[3]||naof[4]||naof[5]);
         xiangmode3(naof[6]||naof[7]||naof[8]);
         xiangmode4(naof[9]||naof[10]||naof[11]);
         xiangnum1(yaol[0],ytype[0]);
         xiangnum2(yaol[1],ytype[1]);
         xiangnum3(yaol[2],ytype[2]);
         xiangnum4(yaol[3],ytype[3]);
         keyscan();
         sos();
         comperatime();
         dingshikai();
           
         fangyao();
         menflag(); 
         
        if((menf1||menf2||menf3||menf4)&&(!naok[0]&&!naok[1]&&!naok[2]&&!naok[3]&&!naok[4]&&!naok[5]&&!naok[6]&&!naok[7]&&!naok[8]&&!naok[9]&&!naok[10]&&!naok[11]))
          {
            mainmode=4;
          }
        if((menf1||menf2||menf3||menf4)&&(naok[0]||naok[1]||naok[2]||naok[3]||naok[4]||naok[5]||naok[6]||naok[7]||naok[8]||naok[9]||naok[10]||naok[11]))
          {
            mainmode=5;
          }

           if(baoshi==1)
             {
             baoshi=0;
             baohour();
              }
           main1kg();
           main1an();
           if(ch2==1)
            {
             shujuon(1);
             ch2=0;  
            }
      
      }
  }
  if(mainmode==2)
    {
      setmodeview(2);
      shujuon(0);
      wifisend(30,">setclock< example:23-30-59&");
     while(mainmode==2)
      {
        modeset2();
      }
    }
 if(mainmode==21)
    {
      setmodeview(2);
      shujuon(0);
      wifisend(36,">setthreshold< example:01-30;05-25&");
     while(mainmode==21)
      {
        modeset21();
      }
    }
    
 if(mainmode==3)
    {
      setmodeview(1);
      shujuon(0);
      wifisend(52,">SetTimer Mode<Which box you want set? 01& to 04&?");
      rx4[1]=0;
      rx4[2]=0;
     while(mainmode==3)
      {
           modeset3();
           if(rx4[1]=='j')
            {
             shujuon(1);
             wifisend(15,"set finished!");
             box=0;
             mainmode=1;
             ch2=0; 
             break; 
            }
      }
    }
    
  if(mainmode==4)
    {
    //InitDS1302();
    setmodeview(3);
    shujuon(0);
    duanxin(0);
      while(mainmode==4)
        {
         GetDS1302();
         wenshicai();
         clockview(55,180,dtime[2][0],dtime[2][1],dtime[1][0],dtime[1][1],dtime[0][0],dtime[0][1],Magenta);
         wenshow(temp,temp1);
         shishow(hum,hum1);
         tempcompare();
         
         fangyao();
         menflag();
         if(!menf1&&!menf2&&!menf3&&!menf4)
          {
            mainmode=1;
          }
         if(baoshi==1)
             {
             baoshi=0;
             baohour();
              }
           main1kg();
    if(rx4[1]=='a')
      {
       kmen1=1; 
      }
    if(rx4[1]=='b')
      {
       kmen2=1; 
      }
    if(rx4[1]=='c')
      {
       kmen3=1; 
      }
    if(rx4[1]=='d')
      {
       kmen4=1; 
      }
    if(rx4[1]=='z'||rx4[1]=='e'||rx4[1]=='f'||rx4[1]=='g'||rx4[1]=='h'||rx4[1]=='l'||rx4[1]=='n'||rx4[1]=='q'||rx4[1]=='r'||rx4[1]=='o'||rx4[1]=='p'||rx4[1]=='i'||rx4[1]=='j')
      {
      shujuon(0);
      ch2=0; 
      }
           if(ch2==1)
            {
             shujuon(1);
             ch2=0;  
            }     
        }
    }
    
  if(mainmode==5)
    {
   // InitDS1302();
    setmodeview(4);
    shujuon(0);
    duanxin(0);
    wifisend(15,"On time open!");
      while(mainmode==5)
        {
         GetDS1302();
         wenshicai();
         clockview(55,180,dtime[2][0],dtime[2][1],dtime[1][0],dtime[1][1],dtime[0][0],dtime[0][1],Magenta);
         wenshow(temp,temp1);
         shishow(hum,hum1);
         tempcompare();
         keyscan();
         comperatime();
         
           
         fangyao();
         menflag();dingshikai();
         main1kg();
         if(rx4[1]=='e')
      {
        if(shishi==1)
        mainmode=12;
      }
      if(rx4[1]=='z')
      {
            shujuon(0);
             ch2=0;
      }
      if(ch2==1)
            {
             shujuon(1);
             ch2=0;  
            }
         if(!k0&&!k1&&!k2&&!k3&&!k4)
          {
           yutixing(); 
           dengdai();
          }
         if(k0)
          {
            if(menf1)baoyao(1,yaol[0],ytype[0]);
             else baoyao(5,0,0);
           wifisend(12,"Check box1");
           duanxin(0);
          }
          if(k1)
            {
            if(menf2)baoyao(2,yaol[1],ytype[1]);
             else baoyao(5,0,0);
           wifisend(12,"Check box2");
           duanxin(0); 
            }
            if(k2)
            {
            if(menf3)baoyao(3,yaol[2],ytype[2]);
             else baoyao(5,0,0);
           wifisend(12,"Check box3"); 
           duanxin(0); 
            }
           if(k3)
            {
            if(menf4)baoyao(4,yaol[3],ytype[3]);
             else baoyao(5,0,0);
           wifisend(12,"Check box4");
           duanxin(0); 
            }
          sos();  
         if(!menf1&&!menf2&&!menf3&&!menf4)
          {
            mainmode=1;
            k0=0;
            k1=0;
            k2=0;
            k3=0;
            jiedian();
            delay1ms(2500);
            yuguanmen();
          }
              
        }
    }
  if(mainmode==11)
    { 
         delay1ms(1500);
         maincn();
      while(mainmode==11)
        {
      if(rx4[1]=='z'||rx4[1]=='a'||rx4[1]=='b'||rx4[1]=='c'||rx4[1]=='d'||rx4[1]=='e'||rx4[1]=='f'||rx4[1]=='g'||rx4[1]=='h'||rx4[1]=='l'||rx4[1]=='n'||rx4[1]=='q'||rx4[1]=='r'||rx4[1]=='o'||rx4[1]=='p')
      {
      shujuon(0);
      ch2=0; 
      }
      if(rx4[1]=='i'||rx4[1]=='j')
      {
      mainmode=1;
      ch2=0; 
      }
      if(ch2==1)
      {
      shujuon(1);
      ch2=0; 
      }
        }

    }
  if(mainmode==12)
    { 
         delay1ms(1500);
         mainzh();
      while(mainmode==12)
        {
        
      if(rx4[1]=='z'||rx4[1]=='a'||rx4[1]=='b'||rx4[1]=='c'||rx4[1]=='d'||rx4[1]=='e'||rx4[1]=='f'||rx4[1]=='g'||rx4[1]=='h'||rx4[1]=='l'||rx4[1]=='n'||rx4[1]=='q'||rx4[1]=='r'||rx4[1]=='o'||rx4[1]=='p')
      {
      shujuon(0);
      ch2=0; 
      }
      if(rx4[1]=='i'||rx4[1]=='j')
      {
      mainmode=1;
      ch2=0; 
      }
      if(ch2==1)
      {
      shujuon(1);
      ch2=0; 
      }
          
        }

    }
   }
}

#pragma CODE_SEG __NEAR_SEG NON_BANKED
void interrupt 20 SCI0_re(void)
{
if(mainmode==0)
{
if(SCI0SR1_RDRF==1) 
{
SCI0SR1_RDRF=1; 
rx[rxcnt]=SCI0DRL;
rx1[rxcnt1]=SCI0DRL; 
wifichu();   
  }
  }
if(mainmode!=0)
  {
   if(SCI0SR1_RDRF==1) 
{
  SCI0SR1_RDRF=1; 
  rx2[rxcnt2]=SCI0DRL;
  wifiorder();
}
  }

}
void interrupt 21 SCI1_re(void)
{

if(SCI1SR1_RDRF==1) 
{
SCI1SR1_RDRF=1; 
chuan=SCI1DRL;
chuan1=SCI1DRL;
if(mainmode!=5)
  {

if(chuan==1)
  {
    kmen1=1;  
  }
else if(chuan==2)
  {
    kmen2=1;
  }
else if(chuan==3)
  {
    kmen3=1;
  }
else if(chuan==4)
  {
    kmen4=1;
  }
if(chuan1==5)
  {
    baoshi=1;
  }
  }
 
}
}
#pragma CODE_SEG DEFAULT