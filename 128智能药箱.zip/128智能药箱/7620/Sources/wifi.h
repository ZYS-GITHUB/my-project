void smartstart()
  {
     Put_string("AT+CWMODE=1\r\n");
     delay_1ms(1500);
     Put_string("AT+CWSTARTSMART\r\n");
     delay_1ms(1500);
  }
void TCPconnect()
  {
    Put_string("AT+CIPMUX=0\r\n");
    delay_1ms(2500);
    Put_string("AT+CIPMODE=0\r\n");
    delay_1ms(2500);
    Put_string("AT+CIPSTART=\"TCP\",\"115.29.109.104\",6582\r\n");
    delay_1ms(2500);
    Put_string("AT+CIPSEND=8\r\n");
    delay_1ms(2500);
    Put_string("Ready!\r\n");
  }
  void wifichu()
  {
    if(rx[0]=='r')
  {
        rxcnt++;
        if(rxcnt>5)
    {  
      
      if(rx[1]=='e'&&rx[4]=='y')
        {
          ch=1;
        }
        
          rxcnt=0;
    }
  }
 else
  {
    rxcnt=0;  
  }
if(rx1[0]=='s')
  {
    rxcnt1++;
  if(rxcnt1>13)
    { rxcnt1=0; 
      if(rx1[12]=='c')
        {
          ch1=1;
        }
        else
          {
           rxcnt1=0;  
          }
    }
  }
 else
  {
    rxcnt1=0;  
  }

  }
 void wifiorder()
  {
     
 if(rx2[0]=='+')
  {
   rxcnt2++;
   if(rxcnt2>1) 
    {
      
    rxcnt2=0;
   if(rx2[1]=='I')
    {
      ch3=1;
      rxcnt2=0;
    }
   else
  {
  rxcnt2=0;  
  } 
  }
  }
 else
  {
  rxcnt2=0;  
  } 
  
  if(ch3==1)
  { 
    
    if(SCI0DRL==':')
      {
        flag=1;
      }
      if(flag==1)
        {
        *(text+txcnt)=SCI0DRL; 
        txcnt++; 
        }
     if(SCI0DRL=='&') 
      { ch2=1;
        rxcnt2=0;
        ch3=0;
        flag=0;
        txcnt=0;
      }
  } 
  }
void wifisend(uchar len,uchar *txt)
  {
    uchar ge,shi;
    ge=len%10+0x30;
    shi=len/10%10+0x30;
    if(len<10)
      {
    Put_string("AT+CIPSEND=");
    SCI0_putchar(len+0x30);
    Put_string("\r\n"); 
    delay_1ms(1500);
    Put_string(txt); 
    Put_string("\r\n");  
      }
    else
      {
     Put_string("AT+CIPSEND=");
     SCI0_putchar(shi);
     SCI0_putchar(ge);
     Put_string("\r\n");
     delay_1ms(1500);
     Put_string(txt); 
     Put_string("\r\n");   
      }
  }
  